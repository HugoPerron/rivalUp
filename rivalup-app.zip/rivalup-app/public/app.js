/**
 * RivalUp — Mobile-First 1v1 Gamified Habit PWA Frontend
 */

const COLOR_PALETTE = [
  { name: 'Electric Blue', hex: '#2563EB' },
  { name: 'Vibrant Coral', hex: '#F97316' },
  { name: 'Emerald', hex: '#10B981' },
  { name: 'Royal Purple', hex: '#7C3AED' },
  { name: 'Hot Rose', hex: '#E11D48' },
  { name: 'Teal', hex: '#0D9488' },
  { name: 'Amber Gold', hex: '#D97706' },
  { name: 'Indigo', hex: '#4F46E5' },
];

const DIFF_NAMES = { 1: 'Easy', 2: 'Medium', 3: 'Hard' };

// ---------- App UI State ----------
const ui = {
  state: null,
  activePlayerId: localStorage.getItem('rivalup_player') || 'p1',
  tab: 'matchday',
  selectedDay: 'today', // 'today' | 'yesterday'
  calendarMode: 'split', // 'split' | 'winner' | 'solo'
  calendarSoloPlayer: 'p1',
  calendarMonth: null, // 'YYYY-MM'
  es: null,
};

// Check URL params for pairing link (?as=p2&join=CODE)
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('as') === 'p1' || urlParams.get('as') === 'p2') {
  ui.activePlayerId = urlParams.get('as');
  localStorage.setItem('rivalup_player', ui.activePlayerId);
}

// ---------- Helpers ----------
function esc(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function hexToRgba(hex, alpha) {
  const clean = (hex || '#2563EB').replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function heatFill(hex, level) {
  const alphas = [0.06, 0.28, 0.52, 0.78, 1.0];
  if (!level || level <= 0) return '#F1F5F9';
  return hexToRgba(hex, alphas[Math.min(4, level)]);
}

function getPlayer(id) {
  return ui.state?.players.find((p) => p.id === id) || { id, name: id, emoji: '⚡', color: '#2563EB' };
}

function getOtherPlayerId(id = ui.activePlayerId) {
  return id === 'p1' ? 'p2' : 'p1';
}

function formatShortDate(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatMonthTitle(ym) {
  const [y, m] = ym.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

function shiftMonth(ym, delta) {
  const [y, m] = ym.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function timeAgo(iso) {
  const sec = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (sec < 60) return 'just now';
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return `${Math.floor(sec / 86400)}d ago`;
}

let toastTimer = null;
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2800);
}

// ---------- Confetti Burst ----------
function launchConfetti(colorHex = '#2563EB') {
  const canvas = document.getElementById('confetti-canvas');
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const colors = [colorHex, '#FACC15', '#10B981', '#F97316', '#A855F7'];
  const pieces = Array.from({ length: 42 }, () => ({
    x: canvas.width * (0.25 + Math.random() * 0.5),
    y: canvas.height * 0.35,
    vx: (Math.random() - 0.5) * 11,
    vy: -6 - Math.random() * 8,
    size: 5 + Math.random() * 5,
    color: colors[Math.floor(Math.random() * colors.length)],
    rot: Math.random() * 360,
    vrot: (Math.random() - 0.5) * 14,
    alpha: 1,
  }));

  let frame = 0;
  function tick() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const p of pieces) {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.36;
      p.rot += p.vrot;
      p.alpha -= 0.017;
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rot * Math.PI) / 180);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.65);
      ctx.restore();
    }
    frame += 1;
    if (frame < 65) requestAnimationFrame(tick);
    else ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
  requestAnimationFrame(tick);
}

// ---------- API Client ----------
async function api(path, body = null) {
  const opts = body
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    : { method: 'GET' };
  const res = await fetch(path, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  if (data.state) {
    ui.state = data.state;
    applyThemeColors();
    render();
  }
  return data;
}

async function fetchState() {
  const qs = ui.calendarMonth ? `?month=${encodeURIComponent(ui.calendarMonth)}` : '';
  const data = await api(`/api/state${qs}`);
  ui.state = data;
  if (!ui.calendarMonth) ui.calendarMonth = data.todayStr.slice(0, 7);
  applyThemeColors();
  render();
}

function applyThemeColors() {
  if (!ui.state) return;
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  document.documentElement.style.setProperty('--p1', p1.color);
  document.documentElement.style.setProperty('--p2', p2.color);
  const active = getPlayer(ui.activePlayerId);
  document.getElementById('active-player-dot').style.background = active.color;
  document.getElementById('active-player-label').textContent = `${active.emoji} ${active.name}`;
}

function connectSSE() {
  if (ui.es) ui.es.close();
  ui.es = new EventSource('/api/events');
  ui.es.addEventListener('update', () => fetchState());
}

// ---------- Photo Helper (Client-side Resize to <900px) ----------
function readImageAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 900;
        let w = img.width;
        let h = img.height;
        if (w > maxDim || h > maxDim) {
          const scale = maxDim / Math.max(w, h);
          w = Math.round(w * scale);
          h = Math.round(h * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = reject;
      img.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ---------- Modal Helpers ----------
function openModal(html) {
  const backdrop = document.getElementById('modal-backdrop');
  const sheet = document.getElementById('modal-sheet');
  sheet.innerHTML = html;
  backdrop.classList.remove('hidden');
}

function closeModal() {
  document.getElementById('modal-backdrop').classList.add('hidden');
}

document.getElementById('modal-backdrop').addEventListener('click', (e) => {
  if (e.target.id === 'modal-backdrop') closeModal();
});

// ---------- Render Router ----------
function updateNavBadges() {
  if (!ui.state) return;
  const openProofs = ui.state.feed.filter(
    (e) => e.type === 'proof_request' && e.target_id === ui.activePlayerId && !e.payload.resolved
  ).length;
  const feedBadge = document.getElementById('feed-badge');
  if (openProofs > 0) {
    feedBadge.textContent = openProofs;
    feedBadge.classList.remove('hidden');
  } else {
    feedBadge.classList.add('hidden');
  }

  const pendingApprovals = ui.state.habits.filter(
    (h) => h.approval_status === 'pending' && h.proposed_by !== ui.activePlayerId
  ).length;
  const lineupBadge = document.getElementById('lineup-badge');
  if (pendingApprovals > 0) {
    lineupBadge.textContent = pendingApprovals;
    lineupBadge.classList.remove('hidden');
  } else {
    lineupBadge.classList.add('hidden');
  }
}

function render() {
  if (!ui.state) return;
  updateNavBadges();
  document.querySelectorAll('.nav-item').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tab === ui.tab);
  });

  const main = document.getElementById('app-main');
  if (ui.tab === 'matchday') main.innerHTML = renderMatchday();
  else if (ui.tab === 'calendar') main.innerHTML = renderCalendar();
  else if (ui.tab === 'feed') main.innerHTML = renderFeed();
  else if (ui.tab === 'lineup') main.innerHTML = renderLineup();
  else if (ui.tab === 'trophies') main.innerHTML = renderTrophies();

  bindTabEvents();
}

// =========================================================================
// TAB 1: MATCHDAY
// =========================================================================
function renderMatchday() {
  const s = ui.state;
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  const me = getPlayer(ui.activePlayerId);
  const rival = getPlayer(getOtherPlayerId());
  const sc1 = s.scores.p1;
  const sc2 = s.scores.p2;
  const myScore = s.scores[me.id];
  const match = s.scores.match;

  const totalSum = Math.max(1, Math.max(0, sc1.totalPoints) + Math.max(0, sc2.totalPoints));
  const p1Pct = sc1.totalPoints === sc2.totalPoints ? 50 : Math.min(88, Math.max(12, Math.round((Math.max(0, sc1.totalPoints) / totalSum) * 100)));
  const p2Pct = 100 - p1Pct;

  let commentary = "Dead even — next check-in breaks the deadlock! ⚡";
  if (match.winnerId === 'p1') commentary = `${p1.name} leads by ${match.margin} pt${match.margin === 1 ? '' : 's'} — ${p2.name}, time for a Double Down?`;
  else if (match.winnerId === 'p2') commentary = `${p2.name} leads by ${match.margin} pt${match.margin === 1 ? '' : 's'} — ${p1.name}, chase it down!`;

  const dayStr = ui.selectedDay === 'today' ? s.todayStr : s.yesterdayStr;
  const dayEdit = ui.selectedDay === 'today' ? s.editability.today : s.editability.yesterday;

  // Build maps for fast lookup on selected day
  const myDayCheckins = new Map();
  const rivalDayCheckins = new Map();
  const myWeekCounts = new Map();
  for (const c of s.currentWeekCheckins) {
    if (c.player_id === me.id && c.date_str === dayStr) myDayCheckins.set(c.habit_id, c);
    if (c.player_id === rival.id && c.date_str === dayStr) rivalDayCheckins.set(c.habit_id, c);
    if (c.player_id === me.id && c.status === 'completed') {
      myWeekCounts.set(c.habit_id, (myWeekCounts.get(c.habit_id) || 0) + 1);
    }
  }
  const myDayDDs = new Set(
    s.currentWeekDoubleDowns.filter((d) => d.player_id === me.id && d.date_str === dayStr).map((d) => d.habit_id)
  );

  const myHabits = s.habits.filter(
    (h) => h.approval_status === 'approved' && (h.owner_id === 'shared' || h.owner_id === me.id)
  );
  const sharedHabits = myHabits.filter((h) => h.owner_id === 'shared');
  const personalHabits = myHabits.filter((h) => h.owner_id === me.id);

  const renderHabitCard = (h) => {
    const chk = myDayCheckins.get(h.id);
    const rivalChk = rivalDayCheckins.get(h.id);
    const isCompleted = chk?.status === 'completed';
    const isSlipped = chk?.status === 'slipped';
    const hasDD = myDayDDs.has(h.id);
    const wkCount = myWeekCounts.get(h.id) || 0;
    const isShared = h.owner_id === 'shared';

    // Current day breakdown item if completed
    const dayItem = myScore.perDay[dayStr]?.items.find((i) => i.habitId === h.id);

    let actionControls = '';
    if (h.kind === 'avoid') {
      actionControls = `
        <div style="display:flex;gap:6px;flex-shrink:0">
          <button class="check-btn ${isCompleted ? 'done' : ''}" data-action="checkin" data-habit="${h.id}" data-status="${isCompleted ? 'uncheck' : 'completed'}" ${!dayEdit.editable ? 'disabled' : ''}>
            ${isCompleted ? '✓ Held' : 'Held'}
          </button>
          <button class="check-btn ${isSlipped ? 'danger' : 'secondary'}" data-action="checkin" data-habit="${h.id}" data-status="${isSlipped ? 'uncheck' : 'slipped'}" ${!dayEdit.editable ? 'disabled' : ''}>
            Slipped
          </button>
        </div>`;
    } else if (h.kind === 'numeric') {
      actionControls = `
        <button class="check-btn ${isCompleted ? 'done' : ''}" data-action="checkin-numeric-quick" data-habit="${h.id}" data-target="${h.target_value}" ${!dayEdit.editable ? 'disabled' : ''}>
          ${isCompleted ? `✓ ${chk.numeric_value}` : `Hit ${h.target_value}`}
        </button>`;
    } else {
      actionControls = `
        <button class="check-btn ${isCompleted ? 'done' : ''}" data-action="checkin" data-habit="${h.id}" data-status="${isCompleted ? 'uncheck' : 'completed'}" ${!dayEdit.editable ? 'disabled' : ''}>
          ${isCompleted ? '✓ Done' : '+ Log'}
        </button>`;
    }

    return `
      <div class="habit-card ${isCompleted ? 'completed' : ''} ${isSlipped ? 'slipped' : ''} ${hasDD && !isCompleted ? 'double-down-active' : ''}">
        <div class="habit-top">
          <div style="min-width:0;flex:1">
            <div class="habit-title">
              <span>${esc(h.title)}</span>
            </div>
            <div class="habit-meta">
              <span class="tag diff-${h.difficulty}">${DIFF_NAMES[h.difficulty]} · ${h.difficulty} pt</span>
              ${isShared ? '<span class="tag shared">⚔️ Shared +1</span>' : ''}
              ${h.cadence === 'weekly' ? `<span class="tag">${wkCount}/${h.target_count} this wk</span>` : '<span class="tag">Daily</span>'}
              ${h.kind === 'avoid' ? '<span class="tag">🛡️ Avoid</span>' : ''}
              ${hasDD ? `<span class="tag dd">🎲 2x DOUBLE DOWN</span>` : ''}
              ${dayItem?.streakBonus ? `<span class="tag streak">🔥 Streak +1</span>` : ''}
              ${isShared && rivalChk?.status === 'completed' ? `<span class="tag rival-done">${rival.emoji} ${esc(rival.name)} logged!</span>` : ''}
            </div>
          </div>
          ${actionControls}
        </div>

        ${h.kind === 'numeric' ? `
          <div class="numeric-row">
            <input type="number" min="0" step="any" placeholder="Enter ${esc(h.unit || 'amount')} (goal: ${h.target_value})" value="${chk?.numeric_value ?? ''}" id="num-input-${h.id}" ${!dayEdit.editable ? 'disabled' : ''}/>
            <button class="action-chip" data-action="save-numeric" data-habit="${h.id}" ${!dayEdit.editable ? 'disabled' : ''}>Save ${esc(h.unit)}</button>
          </div>` : ''}

        <div class="habit-controls">
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${!isCompleted && dayEdit.editable ? `
              <button class="action-chip dd-btn ${hasDD ? 'active' : ''}" data-action="toggle-dd" data-habit="${h.id}" data-active="${hasDD ? '1' : '0'}">
                🎲 ${hasDD ? 'Cancel 2x' : `Double Down (${myScore.doubleDownsRemaining} left)`}
              </button>` : ''}
            ${dayEdit.editable ? `
              <button class="action-chip" data-action="open-note" data-habit="${h.id}">
                📸 ${chk?.note || chk?.photo_url ? 'Edit Note/Pic' : 'Add Note/Pic'}
              </button>` : ''}
          </div>
          ${chk?.note ? `<span style="font-size:0.74rem;color:var(--muted);font-style:italic">"${esc(chk.note)}"</span>` : ''}
        </div>
      </div>`;
  };

  const p1DuoPct = Math.min(100, Math.round((sc1.basePoints / sc1.duoThresholdPoints) * 100));
  const p2DuoPct = Math.min(100, Math.round((sc2.basePoints / sc2.duoThresholdPoints) * 100));

  return `
    <!-- Matchday Hero Scoreboard -->
    <section class="matchday-hero">
      <div class="hero-top">
        <span class="pill-dark">Season ${s.currentWeekMeta.season_num} · Week ${s.currentWeekMeta.week_in_season} of 4</span>
        <span>${formatShortDate(s.currentWeek)} – ${formatShortDate(s.weekDates[6])}</span>
      </div>

      <div class="scoreboard">
        <div class="score-side">
          <div class="score-player">
            <span>${p1.emoji} ${esc(p1.name)}</span>
            ${match.winnerId === 'p1' ? '<span class="crown-badge">👑</span>' : ''}
          </div>
          <div class="score-num" style="color:${p1.color}">${sc1.totalPoints}</div>
          <div class="score-sub">${sc1.basePoints}/${sc1.weeklyBaseBudget} base (${sc1.baseCompletionPct}%)</div>
        </div>

        <div class="vs-pill">VS</div>

        <div class="score-side right">
          <div class="score-player">
            ${match.winnerId === 'p2' ? '<span class="crown-badge">👑</span>' : ''}
            <span>${esc(p2.name)} ${p2.emoji}</span>
          </div>
          <div class="score-num" style="color:${p2.color}">${sc2.totalPoints}</div>
          <div class="score-sub">${sc2.basePoints}/${sc2.weeklyBaseBudget} base (${sc2.baseCompletionPct}%)</div>
        </div>
      </div>

      <div class="tug-bar" aria-label="Live score tug of war">
        <div class="tug-left" style="width:${p1Pct}%"></div>
        <div class="tug-right" style="width:${p2Pct}%"></div>
        <div class="tug-midline"></div>
      </div>

      <div class="hero-commentary">${esc(commentary)}</div>
    </section>

    <!-- Duo Flame Co-op Progress -->
    <section class="card duo-card">
      <div class="duo-header">
        <div class="duo-title">🔥 Duo Flame Co-op <span style="font-weight:600;font-size:0.75rem">(Both ≥${sc1.duoThresholdPoints} base pts)</span></div>
        <span class="duo-streak-pill">${s.duoFlame.currentStreak} wk streak</span>
      </div>
      <div class="duo-bars">
        <div>
          <div class="mini-progress-label">
            <span>${esc(p1.name)}</span>
            <span>${sc1.basePoints}/${sc1.duoThresholdPoints} ${sc1.hitDuoThreshold ? '✅' : ''}</span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:${p1DuoPct}%;background:${p1.color}"></div></div>
        </div>
        <div>
          <div class="mini-progress-label">
            <span>${esc(p2.name)}</span>
            <span>${sc2.basePoints}/${sc2.duoThresholdPoints} ${sc2.hitDuoThreshold ? '✅' : ''}</span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:${p2DuoPct}%;background:${p2.color}"></div></div>
        </div>
      </div>
    </section>

    <!-- Weekly Wager + Mystery Side-Quest -->
    <section class="duo-meta-grid">
      <div class="mini-card clickable" id="edit-wager-card">
        <div class="mini-card-kicker"><span>🤝 Weekly Wager</span><span>Edit ✎</span></div>
        <div class="mini-card-main">${esc(s.currentWeekMeta.wager_text)}</div>
        <div class="mini-card-sub">Season tally: ${p1.name} ${s.records.seasonWins.p1} – ${s.records.seasonWins.p2} ${p2.name}</div>
      </div>
      <div class="mini-card">
        <div class="mini-card-kicker"><span>${myScore.quest.emoji} Side-Quest</span><span style="color:var(--gold)">+${myScore.quest.bonus} pts</span></div>
        <div class="mini-card-main">${esc(myScore.quest.title)}</div>
        <div class="mini-card-sub">${esc(myScore.quest.description)}</div>
        <div class="mini-card-sub" style="color:${myScore.quest.completed ? 'var(--green)' : 'var(--dark)'};font-weight:800">
          ${myScore.quest.completed ? '✅ Unlocked (+4 pts!)' : esc(myScore.quest.label)}
        </div>
      </div>
    </section>

    <!-- Day Switcher + Morning Grace Period -->
    <section class="day-bar">
      <div class="segmented">
        <button data-day="today" class="${ui.selectedDay === 'today' ? 'active' : ''}">Today (${formatShortDate(s.todayStr)})</button>
        <button data-day="yesterday" class="${ui.selectedDay === 'yesterday' ? 'active' : ''}">Yesterday</button>
      </div>
      <span class="grace-pill ${dayEdit.editable ? '' : 'locked'}">${esc(dayEdit.label)}</span>
    </section>

    <!-- Shared Head-to-Head Habits -->
    <section>
      <div class="card-title-row">
        <span class="section-label">⚔️ Shared Head-to-Head (+1 Bonus)</span>
        <span class="section-label">${esc(me.name)}'s Check-ins</span>
      </div>
      <div class="habit-list">
        ${sharedHabits.length ? sharedHabits.map(renderHabitCard).join('') : '<div class="card" style="color:var(--muted);font-size:0.85rem">No shared habits yet — add one in Lineup!</div>'}
      </div>
    </section>

    <!-- Personal Habits -->
    <section>
      <div class="card-title-row">
        <span class="section-label">${me.emoji} ${esc(me.name)}'s Personal Habits</span>
        <span class="section-label">🎲 ${myScore.doubleDownsRemaining}/2 Double Downs left</span>
      </div>
      <div class="habit-list">
        ${personalHabits.length ? personalHabits.map(renderHabitCard).join('') : '<div class="card" style="color:var(--muted);font-size:0.85rem">No personal habits yet — add some in Lineup!</div>'}
      </div>
    </section>

    <!-- Transparent Score Math Breakdown -->
    <section class="card">
      <details class="math-details">
        <summary>
          <span>🧮 Transparent Score Breakdown (This Week)</span>
          <span>Show math ▾</span>
        </summary>
        <table class="math-table">
          <thead>
            <tr>
              <th>Component</th>
              <th style="color:${p1.color}">${esc(p1.name)}</th>
              <th style="color:${p2.color}">${esc(p2.name)}</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>Base Habit Points (cap ${sc1.weeklyBaseBudget})</td><td>${sc1.basePoints}</td><td>${sc2.basePoints}</td></tr>
            <tr><td>Shared Head-to-Head (+1 each)</td><td>+${sc1.sharedBonus}</td><td>+${sc2.sharedBonus}</td></tr>
            <tr><td>Hot-Streak Bonus (3+ days / wk goal)</td><td>+${sc1.streakBonus}</td><td>+${sc2.streakBonus}</td></tr>
            <tr><td>Double Down Bets (2x hit / -1 miss)</td><td>${sc1.doubleDownDelta >= 0 ? '+' : ''}${sc1.doubleDownDelta}</td><td>${sc2.doubleDownDelta >= 0 ? '+' : ''}${sc2.doubleDownDelta}</td></tr>
            <tr><td>Mystery Side-Quest (+4)</td><td>+${sc1.questBonus}</td><td>+${sc2.questBonus}</td></tr>
            <tr class="total-row"><td>Total Match Score</td><td>${sc1.totalPoints}</td><td>${sc2.totalPoints}</td></tr>
          </tbody>
        </table>
      </details>
    </section>
  `;
}

// =========================================================================
// TAB 2: CALENDAR & SHARED DUAL-COLOR HEATMAP
// =========================================================================
function renderCalendar() {
  const s = ui.state;
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  const ym = ui.calendarMonth || s.todayStr.slice(0, 7);
  const [year, month] = ym.split('-').map(Number);

  const firstOfMonth = new Date(year, month - 1, 1);
  const daysInMonth = new Date(year, month, 0).getDate();
  const startOffset = (firstOfMonth.getDay() + 6) % 7; // Mon=0 ... Sun=6

  let cellsHtml = '';
  for (let i = 0; i < startOffset; i++) {
    cellsHtml += '<div class="cal-cell empty"></div>';
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const info = s.heatmap[dateStr];
    const p1Lvl = info?.p1.level || 0;
    const p2Lvl = info?.p2.level || 0;
    const isToday = dateStr === s.todayStr;
    const bothCrushed = Boolean(info?.bothCrushed);

    let bgHtml = '';
    if (ui.calendarMode === 'split') {
      const c1 = heatFill(p1.color, p1Lvl);
      const c2 = heatFill(p2.color, p2Lvl);
      bgHtml = `
        <svg class="cal-split-svg" viewBox="0 0 100 100" preserveAspectRatio="none">
          <polygon points="0,0 100,0 0,100" fill="${c1}" />
          <polygon points="100,0 100,100 0,100" fill="${c2}" />
          <line x1="0" y1="100" x2="100" y2="0" stroke="rgba(255,255,255,0.75)" stroke-width="2.5" />
        </svg>`;
    } else if (ui.calendarMode === 'winner') {
      let fill = '#F1F5F9';
      if (info?.winner === 'p1') fill = heatFill(p1.color, Math.max(2, p1Lvl));
      else if (info?.winner === 'p2') fill = heatFill(p2.color, Math.max(2, p2Lvl));
      else if (info?.winner === 'tie') fill = 'linear-gradient(135deg, #FACC15, #F59E0B)';
      bgHtml = `<div style="width:100%;height:100%;background:${fill}"></div>`;
    } else {
      const target = ui.calendarSoloPlayer === 'p1' ? p1 : p2;
      const lvl = ui.calendarSoloPlayer === 'p1' ? p1Lvl : p2Lvl;
      bgHtml = `<div style="width:100%;height:100%;background:${heatFill(target.color, lvl)}"></div>`;
    }

    cellsHtml += `
      <button class="cal-cell ${isToday ? 'today' : ''} ${bothCrushed && ui.calendarMode === 'split' ? 'both-crushed' : ''}" data-cal-date="${dateStr}">
        ${bgHtml}
        <span class="cal-day-num">${day}</span>
        ${bothCrushed ? '<span class="cal-star">⭐</span>' : ''}
      </button>`;
  }

  // Build 12-week rolling overview strip (84 days ending this week's Sunday)
  const allDates = Object.keys(s.heatmap).sort();
  const last84 = allDates.slice(-84);
  let stripColsHtml = '';
  for (let col = 0; col < Math.ceil(last84.length / 7); col++) {
    const slice = last84.slice(col * 7, col * 7 + 7);
    stripColsHtml += `<div class="contrib-col">${slice
      .map((d) => {
        const info = s.heatmap[d];
        let style = 'background:#F1F5F9';
        if (ui.calendarMode === 'solo') {
          const p = ui.calendarSoloPlayer === 'p1' ? p1 : p2;
          const lvl = ui.calendarSoloPlayer === 'p1' ? info.p1.level : info.p2.level;
          style = `background:${heatFill(p.color, lvl)}`;
        } else if (ui.calendarMode === 'winner') {
          if (info.winner === 'p1') style = `background:${p1.color}`;
          else if (info.winner === 'p2') style = `background:${p2.color}`;
          else if (info.winner === 'tie') style = 'background:#F59E0B';
        } else {
          const c1 = heatFill(p1.color, info.p1.level);
          const c2 = heatFill(p2.color, info.p2.level);
          style = `background:linear-gradient(135deg, ${c1} 50%, ${c2} 50%)`;
        }
        return `<div class="contrib-dot" style="${style}" data-cal-date="${d}" title="${d}"></div>`;
      })
      .join('')}</div>`;
  }

  return `
    <section class="card">
      <div class="cal-header">
        <button class="cal-nav-btn" id="cal-prev">‹</button>
        <div class="cal-month-title">${formatMonthTitle(ym)}</div>
        <button class="cal-nav-btn" id="cal-next">›</button>
      </div>

      <div style="display:flex;justify-content:center;margin-bottom:10px;gap:6px;flex-wrap:wrap">
        <div class="segmented">
          <button data-cal-mode="split" class="${ui.calendarMode === 'split' ? 'active' : ''}">Shared Split</button>
          <button data-cal-mode="winner" class="${ui.calendarMode === 'winner' ? 'active' : ''}">Daily Winner</button>
          <button data-cal-mode="solo" class="${ui.calendarMode === 'solo' ? 'active' : ''}">Solo</button>
        </div>
        ${ui.calendarMode === 'solo' ? `
          <div class="segmented">
            <button data-solo-p="p1" class="${ui.calendarSoloPlayer === 'p1' ? 'active' : ''}">${p1.emoji} ${esc(p1.name)}</button>
            <button data-solo-p="p2" class="${ui.calendarSoloPlayer === 'p2' ? 'active' : ''}">${p2.emoji} ${esc(p2.name)}</button>
          </div>` : ''}
      </div>

      <div class="cal-weekdays">
        <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
      </div>
      <div class="cal-grid">${cellsHtml}</div>

      <div class="cal-legend">
        <div class="legend-row">
          <span>↖ Top-Left: <strong style="color:${p1.color}">${p1.emoji} ${esc(p1.name)}</strong></span>
          <div class="swatches">
            ${[0, 1, 2, 3, 4].map((l) => `<span class="swatch" style="background:${heatFill(p1.color, l)}"></span>`).join('')}
          </div>
        </div>
        <div class="legend-row">
          <span>↘ Bottom-Right: <strong style="color:${p2.color}">${p2.emoji} ${esc(p2.name)}</strong></span>
          <div class="swatches">
            ${[0, 1, 2, 3, 4].map((l) => `<span class="swatch" style="background:${heatFill(p2.color, l)}"></span>`).join('')}
          </div>
        </div>
        <div class="legend-row" style="font-size:0.7rem">
          <span>⭐ Gold border = Both scored 5+ pts</span>
          <span>Tap any day for full details</span>
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-title-row">
        <span class="section-label">🔥 12-Week Long-Term Heatmap</span>
        <span class="section-label">1 col = 1 wk</span>
      </div>
      <div class="contrib-grid">${stripColsHtml}</div>
    </section>
  `;
}

function openDayDetailModal(dateStr) {
  const info = ui.state.heatmap[dateStr];
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  if (!info) {
    showToast('No logged data for this date yet.');
    return;
  }

  const renderPlayerBlock = (player, d) => `
    <div style="background:var(--surface-alt);border-radius:14px;padding:12px;margin-bottom:10px;border-left:4px solid ${player.color}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <strong style="font-size:0.95rem">${player.emoji} ${esc(player.name)}</strong>
        <strong style="font-size:1.1rem;color:${player.color}">${d.totalPoints} pts</strong>
      </div>
      <div style="font-size:0.74rem;color:var(--muted);margin-bottom:6px">
        Base ${d.basePoints} · Shared +${d.sharedBonus} · Streak +${d.streakBonus} · 2x ${d.doubleDownDelta >= 0 ? '+' : ''}${d.doubleDownDelta}
      </div>
      ${d.items.length
        ? d.items
            .map(
              (it) => `
            <div style="font-size:0.82rem;padding:4px 0;border-top:1px dashed var(--border)">
              <strong>✓ ${esc(it.title)}</strong>
              <span style="color:var(--muted)"> (${it.basePoints + it.sharedBonus + it.streakBonus + it.doubleDownDelta} pts)</span>
              ${it.note ? `<div style="font-size:0.76rem;color:var(--muted);font-style:italic">"${esc(it.note)}"</div>` : ''}
              ${it.photoUrl ? `<img src="${esc(it.photoUrl)}" class="feed-photo" alt="Proof photo" />` : ''}
            </div>`
            )
            .join('')
        : '<div style="font-size:0.8rem;color:var(--muted)">No habits logged this day.</div>'}
    </div>`;

  openModal(`
    <div class="card-title-row">
      <h3 style="margin:0;font-size:1.05rem">📅 ${formatShortDate(dateStr)} Breakdown</h3>
      <button class="action-chip" id="close-modal-btn">Close ✕</button>
    </div>
    ${info.bothCrushed ? '<div style="margin-bottom:10px;font-size:0.82rem;font-weight:800;color:#B45309">⭐ Both players crushed it (5+ pts each)!</div>' : ''}
    ${renderPlayerBlock(p1, info.p1)}
    ${renderPlayerBlock(p2, info.p2)}
  `);
  document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
}

// =========================================================================
// TAB 3: FEED (BANTER & PICS OR IT DIDN'T HAPPEN)
// =========================================================================
function renderFeed() {
  const s = ui.state;
  const me = getPlayer(ui.activePlayerId);
  const rival = getPlayer(getOtherPlayerId());
  const myProofTokens = s.proofTokens[me.id];

  const openChallenges = s.feed.filter(
    (e) => e.type === 'proof_request' && e.target_id === me.id && !e.payload.resolved
  );

  return `
    <!-- Quick Banter Bar -->
    <section class="card">
      <div class="card-title-row">
        <span class="section-label">💬 Quick Banter → ${rival.emoji} ${esc(rival.name)}</span>
        <span class="section-label">📸 ${myProofTokens}/${s.proofTokens.maxPerWeek} challenges left</span>
      </div>
      <div class="banter-bar">
        <button class="banter-pill" data-quick-taunt="👏|Crushing it today! Keep the Duo Flame alive 🔥">👏 Cheer</button>
        <button class="banter-pill" data-quick-taunt="🔥|You're on fire! Still gonna beat you Sunday though 😤">🔥 Fire</button>
        <button class="banter-pill" data-quick-taunt="👀|Quiet on the scoreboard today… slacking?">👀 Nudge</button>
        <button class="banter-pill" id="custom-taunt-btn">✍️ Custom</button>
      </div>
    </section>

    <!-- Open Proof Challenges for Active Player -->
    ${openChallenges
      .map(
        (ch) => `
      <section class="card proof-alert">
        <div style="font-weight:900;font-size:0.95rem;color:#BE123C">📸 Pics or it didn't happen!</div>
        <div style="font-size:0.84rem;margin:4px 0 10px">
          <strong>${esc(getPlayer(ch.actor_id).name)}</strong> challenged your <strong>${esc(ch.payload.habitTitle)}</strong> check-in:
          <em>"${esc(ch.payload.message)}"</em>
        </div>
        <button class="btn-primary" style="background:#E11D48" data-reply-proof="${ch.id}">📸 Upload Proof Photo / Note</button>
      </section>`
      )
      .join('')}

    <!-- Live Feed Stream -->
    <section style="display:flex;flex-direction:column;gap:10px">
      ${s.feed
        .map((ev) => {
          const actor = getPlayer(ev.actor_id);
          const p = ev.payload || {};
          let title = '';
          let note = '';
          let photo = p.photoUrl || p.replyPhotoUrl || '';
          let extraAction = '';

          if (ev.type === 'checkin') {
            title = `${esc(actor.name)} ${p.status === 'slipped' ? 'honestly logged a slip on' : 'completed'} ${esc(p.habitTitle)}`;
            note = p.note || (p.numericValue && p.unit ? `Logged ${p.numericValue} ${p.unit}` : '');
            if (ev.actor_id !== me.id && ev.checkin_id && p.status !== 'slipped') {
              const alreadyChallenged = s.feed.some((f) => f.type === 'proof_request' && f.checkin_id === ev.checkin_id);
              extraAction = alreadyChallenged
                ? '<span class="tag" style="margin-top:6px">📸 Proof requested</span>'
                : `<button class="action-chip" style="margin-top:6px" data-request-proof="${ev.checkin_id}" ${myProofTokens <= 0 ? 'disabled' : ''}>📸 Pics or it didn't happen</button>`;
            }
          } else if (ev.type === 'taunt') {
            title = `${p.emoji || '💬'} ${esc(actor.name)} sent a nudge`;
            note = p.text;
          } else if (ev.type === 'double_down') {
            title = `🎲 ${esc(actor.name)} called DOUBLE DOWN on ${esc(p.habitTitle)}!`;
            note = `Betting 2x points (${(p.difficulty || 1) * 2} pts on hit, -1 pt on miss)`;
          } else if (ev.type === 'proof_request') {
            title = `📸 ${esc(actor.name)} called "Pics or it didn't happen!"`;
            note = `${p.habitTitle}: "${p.message}" ${p.resolved ? '— ✅ Receipts verified!' : '— Waiting on proof…'}`;
          } else if (ev.type === 'proof_reply') {
            title = `✅ ${esc(actor.name)} brought receipts for ${esc(p.habitTitle)}`;
            note = p.note || 'Proof uploaded!';
          } else if (ev.type === 'approval') {
            title = `⚖️ ${esc(actor.name)} proposed a mid-season habit`;
            note = `${p.habitTitle} (${DIFF_NAMES[p.difficulty] || 'Easy'}) — review in Lineup`;
          }

          return `
            <div class="feed-item">
              <div class="feed-avatar" style="background:${actor.color}">${actor.emoji}</div>
              <div class="feed-body">
                <div class="feed-title">${title}</div>
                ${note ? `<div class="feed-note">${esc(note)}</div>` : ''}
                ${photo ? `<img src="${esc(photo)}" class="feed-photo" alt="Check-in proof" />` : ''}
                ${extraAction}
                <div class="feed-time">${timeAgo(ev.created_at)}</div>
              </div>
            </div>`;
        })
        .join('')}
    </section>
  `;
}

// =========================================================================
// TAB 4: LINEUP (HABITS & 4-WEEK SEASON TRANSFER WINDOW)
// =========================================================================
function renderLineup() {
  const s = ui.state;
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  const me = getPlayer(ui.activePlayerId);
  const cap = s.config.weeklyBaseBudget;
  const b1 = s.budgets.p1IncludingPending;
  const b2 = s.budgets.p2IncludingPending;

  const pendingForMe = s.habits.filter((h) => h.approval_status === 'pending' && h.proposed_by !== me.id);
  const myPending = s.habits.filter((h) => h.approval_status === 'pending' && h.proposed_by === me.id);

  const habitRow = (h) => {
    const pts = h.difficulty * (h.cadence === 'daily' ? 7 : h.target_count);
    return `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 0;border-bottom:1px solid var(--border)">
        <div>
          <div style="font-weight:800;font-size:0.9rem">${esc(h.title)} ${h.approval_status === 'pending' ? '<span class="tag" style="background:#FEF3C7;color:#B45309">Pending approval</span>' : ''}</div>
          <div style="font-size:0.75rem;color:var(--muted)">
            ${DIFF_NAMES[h.difficulty]} (${h.difficulty}pt) · ${h.cadence === 'daily' ? 'Daily (7x)' : `${h.target_count}x/week`}
            ${h.kind === 'numeric' ? ` · Goal: ${h.target_value} ${esc(h.unit)}` : ''}
            ${h.kind === 'avoid' ? ' · 🛡️ Avoid' : ''}
            · <strong>${pts} base pts/wk</strong>
          </div>
        </div>
        <button class="action-chip" data-delete-habit="${h.id}" title="Archive habit">✕</button>
      </div>`;
  };

  return `
    <!-- 4-Week Season Salary Cap & Transfer Window -->
    <section class="card">
      <div class="card-title-row">
        <div>
          <div style="font-weight:900;font-size:1rem">Season ${s.config.seasonNum} Lineup (4-Week Cycle)</div>
          <div style="font-size:0.76rem;color:var(--muted)">
            ${s.config.transferWindowOpen
              ? '🟢 Transfer Window OPEN — edit habits freely, then approve each other.'
              : '🔒 Locked for this 4-week Season — habits carry over automatically every week.'}
          </div>
        </div>
      </div>

      <div class="budget-grid">
        <div class="budget-box ${b1 > cap ? 'over' : ''}">
          <div style="font-size:0.75rem;font-weight:800;color:${p1.color}">${p1.emoji} ${esc(p1.name)}</div>
          <div style="font-size:1.35rem;font-weight:900">${b1} <span style="font-size:0.8rem;color:var(--muted)">/ ${cap} pts</span></div>
          <div style="font-size:0.7rem;color:var(--muted)">${p1.approved_season >= s.config.seasonNum ? '✅ Approved lineup' : '⏳ Needs approval'}</div>
        </div>
        <div class="budget-box ${b2 > cap ? 'over' : ''}">
          <div style="font-size:0.75rem;font-weight:800;color:${p2.color}">${p2.emoji} ${esc(p2.name)}</div>
          <div style="font-size:1.35rem;font-weight:900">${b2} <span style="font-size:0.8rem;color:var(--muted)">/ ${cap} pts</span></div>
          <div style="font-size:0.7rem;color:var(--muted)">${p2.approved_season >= s.config.seasonNum ? '✅ Approved lineup' : '⏳ Needs approval'}</div>
        </div>
      </div>

      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
        <button class="btn-primary" style="flex:1" id="add-habit-btn">+ Add Habit</button>
        ${s.config.transferWindowOpen
          ? `<button class="btn-secondary" style="flex:1;border-color:var(--green);color:#047857" id="approve-season-btn">
               ${me.approved_season >= s.config.seasonNum ? '✅ You Approved' : '👍 Approve Rival Lineup'}
             </button>`
          : `<button class="btn-secondary" style="flex:1" id="open-transfer-btn">🔄 Open 4-Wk Transfer Window</button>`}
      </div>
    </section>

    <!-- Pending Mid-Season Approvals -->
    ${pendingForMe.length ? `
      <section class="card" style="background:#FFFBEB;border-color:#F59E0B">
        <div style="font-weight:900;font-size:0.9rem;color:#92400E;margin-bottom:8px">⚖️ Fair-Play Approval Needed</div>
        ${pendingForMe
          .map(
            (h) => `
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 0">
            <div>
              <strong>${esc(h.title)}</strong>
              <div style="font-size:0.75rem;color:#78350F">${DIFF_NAMES[h.difficulty]} (${h.difficulty}pt) · ${h.cadence === 'daily' ? 'Daily' : `${h.target_count}x/wk`}</div>
            </div>
            <div style="display:flex;gap:6px">
              <button class="action-chip" style="background:var(--green);color:#fff;border:none" data-approve-habit="${h.id}">✓ Approve</button>
              <button class="action-chip" style="background:#FEE2E2;color:#B91C1C;border:none" data-delete-habit="${h.id}">✕</button>
            </div>
          </div>`
          )
          .join('')}
      </section>` : ''}

    ${myPending.length ? `<div class="card" style="font-size:0.8rem;color:var(--muted)">⏳ Waiting on ${esc(getPlayer(getOtherPlayerId()).name)} to approve ${myPending.length} mid-season habit(s).</div>` : ''}

    <!-- Habit Lists -->
    <section class="card">
      <div class="section-label" style="margin-bottom:6px">⚔️ Shared Head-to-Head Habits (Counts for both)</div>
      ${s.habits.filter((h) => h.owner_id === 'shared').map(habitRow).join('') || '<div style="font-size:0.82rem;color:var(--muted)">None yet</div>'}
    </section>

    <section class="card">
      <div class="section-label" style="margin-bottom:6px;color:${p1.color}">${p1.emoji} ${esc(p1.name)}'s Personal Habits</div>
      ${s.habits.filter((h) => h.owner_id === 'p1').map(habitRow).join('') || '<div style="font-size:0.82rem;color:var(--muted)">None yet</div>'}
    </section>

    <section class="card">
      <div class="section-label" style="margin-bottom:6px;color:${p2.color}">${p2.emoji} ${esc(p2.name)}'s Personal Habits</div>
      ${s.habits.filter((h) => h.owner_id === 'p2').map(habitRow).join('') || '<div style="font-size:0.82rem;color:var(--muted)">None yet</div>'}
    </section>
  `;
}

// =========================================================================
// TAB 5: TROPHIES (SEASON RECORD, DUO MILESTONES, WAGER LEDGER)
// =========================================================================
function renderTrophies() {
  const s = ui.state;
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');

  return `
    <!-- Head-to-Head Records -->
    <section class="record-grid">
      <div class="record-card">
        <div style="font-size:0.72rem;color:#94A3B8;font-weight:800">SEASON ${s.config.seasonNum} RECORD</div>
        <div class="record-big">
          <span style="color:${p1.color}">${s.records.seasonWins.p1}</span> – <span style="color:${p2.color}">${s.records.seasonWins.p2}</span>
        </div>
        <div style="font-size:0.74rem;color:#CBD5E1">${esc(p1.name)} vs ${esc(p2.name)}</div>
      </div>
      <div class="record-card">
        <div style="font-size:0.72rem;color:#94A3B8;font-weight:800">DUO FLAME STREAK</div>
        <div class="record-big" style="color:#FACC15">🔥 ${s.duoFlame.currentStreak} wks</div>
        <div style="font-size:0.74rem;color:#CBD5E1">Best ever: ${s.duoFlame.longestStreak} wks</div>
      </div>
    </section>

    <!-- Duo Flame Real-Life Milestones -->
    <section class="card">
      <div class="card-title-row">
        <span class="section-label">🎁 Shared Duo Flame Milestones</span>
        <button class="action-chip" id="add-milestone-btn">+ Add Reward</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${s.duoFlame.milestones
          .map(
            (m) => `
          <div class="milestone-item ${m.unlocked ? 'unlocked' : ''}">
            <span style="font-size:1.5rem">${m.emoji}</span>
            <div style="flex:1">
              <div style="font-weight:800;font-size:0.88rem">${esc(m.title)}</div>
              <div style="font-size:0.74rem;color:var(--muted)">${m.weeks_required}-week Duo Flame streak ${m.unlocked ? '· 🎉 UNLOCKED!' : `· ${Math.max(0, m.weeks_required - s.duoFlame.currentStreak)} wk(s) to go`}</div>
            </div>
            <button class="action-chip" data-del-ms="${m.id}">✕</button>
          </div>`
          )
          .join('')}
      </div>
    </section>

    <!-- Weekly Match History & Wager Debt Tracker -->
    <section style="display:flex;flex-direction:column;gap:10px">
      <div class="section-label">📜 Weekly Matches & Wager Ledger</div>
      ${s.weeklyHistory
        .map((w) => {
          const winner = w.winnerId === 'p1' ? p1 : w.winnerId === 'p2' ? p2 : null;
          return `
            <div class="week-history-card">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <strong style="font-size:0.88rem">S${w.seasonNum} · Week ${w.weekInSeason} (${formatShortDate(w.weekStart)})</strong>
                <span class="tag" style="${w.isCurrent ? 'background:#DBEAFE;color:#1D4ED8' : ''}">
                  ${w.isCurrent ? 'LIVE NOW' : winner ? `👑 ${esc(winner.name)} won` : '🤝 Draw'}
                </span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.95rem;font-weight:900">
                <span style="color:${p1.color}">${p1.emoji} ${esc(p1.name)}: ${w.p1.totalPoints} pts</span>
                <span style="color:${p2.color}">${w.p2.totalPoints} pts :${esc(p2.name)} ${p2.emoji}</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.76rem;color:var(--muted);flex-wrap:wrap;gap:6px">
                <span>🤝 ${esc(w.wagerText)}</span>
                <div style="display:flex;gap:6px;align-items:center">
                  ${w.duoFlameEarned ? '<span class="tag streak">🔥 Duo Flame</span>' : ''}
                  ${w.isCompleted ? `
                    <button class="action-chip" style="${w.wagerPaid ? 'background:#DCFCE7;color:#15803D;border-color:#86EFAC' : 'background:#FEF3C7;color:#B45309'}" data-toggle-paid="${w.weekStart}" data-paid="${w.wagerPaid ? '1' : '0'}">
                      ${w.wagerPaid ? '✓ Wager Paid' : 'Mark Paid'}
                    </button>` : ''}
                </div>
              </div>
              ${w.tieBreaker ? `<div style="font-size:0.72rem;color:#6D28D9;font-weight:700">${esc(w.tieBreaker)}</div>` : ''}
            </div>`;
        })
        .join('')}
    </section>
  `;
}

// =========================================================================
// MODALS: NOTE/PHOTO, ADD HABIT, WAGER, PROOF REPLY, SETTINGS & PUSH
// =========================================================================
function openNotePhotoModal(habitId) {
  const s = ui.state;
  const dayStr = ui.selectedDay === 'today' ? s.todayStr : s.yesterdayStr;
  const h = s.habits.find((x) => x.id === habitId);
  const existing = s.currentWeekCheckins.find(
    (c) => c.habit_id === habitId && c.player_id === ui.activePlayerId && c.date_str === dayStr
  );

  openModal(`
    <div class="card-title-row">
      <h3 style="margin:0">📸 Note & Photo — ${esc(h?.title)}</h3>
      <button class="action-chip" id="close-modal-btn">✕</button>
    </div>
    <div class="form-group">
      <label>Quick note (optional)</label>
      <input type="text" id="chk-note-input" placeholder="e.g. 5k PR in the rain!" value="${esc(existing?.note || '')}" />
    </div>
    <div class="form-group">
      <label>Attach proof photo (optional)</label>
      <input type="file" id="chk-photo-input" accept="image/*" capture="environment" />
    </div>
    <button class="btn-primary" id="save-note-btn">Save & Log Check-in</button>
  `);

  document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
  document.getElementById('save-note-btn')?.addEventListener('click', async () => {
    try {
      const note = document.getElementById('chk-note-input').value;
      const file = document.getElementById('chk-photo-input').files[0];
      const photoDataUrl = file ? await readImageAsDataUrl(file) : '';
      await api('/api/checkin', {
        habitId,
        playerId: ui.activePlayerId,
        dateStr: dayStr,
        status: 'completed',
        numericValue: h.kind === 'numeric' ? existing?.numeric_value || h.target_value : null,
        note,
        photoDataUrl,
      });
      closeModal();
      launchConfetti(getPlayer(ui.activePlayerId).color);
      showToast('Saved with note/photo! 🔥');
    } catch (err) {
      showToast(err.message);
    }
  });
}

function openAddHabitModal() {
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  const me = getPlayer(ui.activePlayerId);
  const cap = ui.state.config.weeklyBaseBudget;

  openModal(`
    <div class="card-title-row">
      <h3 style="margin:0">➕ Add New Habit</h3>
      <button class="action-chip" id="close-modal-btn">✕</button>
    </div>
    <div class="form-group">
      <label>Habit Name</label>
      <input id="nh-title" type="text" placeholder="e.g. Morning run, No sugar, Read 20 min" />
    </div>
    <div class="form-group">
      <label>Who is this for?</label>
      <select id="nh-owner">
        <option value="${me.id}">${me.emoji} Personal (${esc(me.name)} only)</option>
        <option value="shared">⚔️ Shared Head-to-Head (Both players · +1 bonus)</option>
      </select>
    </div>
    <div class="form-group">
      <label>Habit Type</label>
      <select id="nh-kind">
        <option value="check">✅ Standard Check-in (Yes/No)</option>
        <option value="numeric">🔢 Numeric Target (Steps, minutes, pages…)</option>
        <option value="avoid">🛡️ Avoid / Bad Habit (Held Strong vs Slipped)</option>
      </select>
    </div>
    <div id="nh-numeric-fields" class="hidden" style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div class="form-group">
        <label>Target Number</label>
        <input id="nh-target-val" type="number" value="30" min="1" />
      </div>
      <div class="form-group">
        <label>Unit</label>
        <input id="nh-unit" type="text" placeholder="min / steps / km" value="min" />
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div class="form-group">
        <label>Schedule</label>
        <select id="nh-cadence">
          <option value="daily">Every day (7x/wk)</option>
          <option value="weekly">X times per week</option>
        </select>
      </div>
      <div class="form-group hidden" id="nh-weekly-count-wrap">
        <label>Times / Week</label>
        <input id="nh-target-count" type="number" min="1" max="6" value="3" />
      </div>
    </div>
    <div class="form-group">
      <label>Difficulty Tier</label>
      <select id="nh-diff">
        <option value="1">Easy — 1 pt per check-in</option>
        <option value="2">Medium — 2 pts per check-in</option>
        <option value="3">Hard — 3 pts per check-in</option>
      </select>
    </div>
    <div id="nh-budget-preview" style="font-size:0.8rem;font-weight:800;padding:8px 10px;border-radius:10px;background:var(--surface-alt);margin-bottom:12px"></div>
    <button class="btn-primary" id="save-habit-btn">Add to Lineup</button>
  `);

  const updatePreview = () => {
    const kind = document.getElementById('nh-kind').value;
    const cadence = document.getElementById('nh-cadence').value;
    document.getElementById('nh-numeric-fields').classList.toggle('hidden', kind !== 'numeric');
    document.getElementById('nh-weekly-count-wrap').classList.toggle('hidden', cadence !== 'weekly');
    const diff = Number(document.getElementById('nh-diff').value);
    const cnt = cadence === 'daily' ? 7 : Number(document.getElementById('nh-target-count').value || 3);
    const addPts = diff * cnt;
    const curMine = ui.state.budgets[`${me.id}IncludingPending`];
    const newTotal = curMine + addPts;
    const el = document.getElementById('nh-budget-preview');
    el.textContent = `Adds +${addPts} base pts/wk → Your lineup: ${newTotal}/${cap} pts ${newTotal > cap ? '⚠️ Over cap!' : '✅'}`;
    el.style.color = newTotal > cap ? 'var(--red)' : '#047857';
  };
  ['nh-kind', 'nh-cadence', 'nh-diff', 'nh-target-count'].forEach((id) =>
    document.getElementById(id).addEventListener('change', updatePreview)
  );
  updatePreview();

  document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
  document.getElementById('save-habit-btn')?.addEventListener('click', async () => {
    try {
      await api('/api/habits', {
        ownerId: document.getElementById('nh-owner').value,
        proposedBy: ui.activePlayerId,
        title: document.getElementById('nh-title').value,
        kind: document.getElementById('nh-kind').value,
        cadence: document.getElementById('nh-cadence').value,
        targetCount: Number(document.getElementById('nh-target-count').value || 3),
        targetValue: Number(document.getElementById('nh-target-val').value || 1),
        unit: document.getElementById('nh-unit').value,
        difficulty: Number(document.getElementById('nh-diff').value),
      });
      closeModal();
      showToast(ui.state.config.transferWindowOpen ? 'Habit added to lineup!' : 'Sent to your rival for Fair-Play approval!');
    } catch (err) {
      showToast(err.message);
    }
  });
}

function openSettingsModal() {
  const s = ui.state;
  const p1 = getPlayer('p1');
  const p2 = getPlayer('p2');
  const me = getPlayer(ui.activePlayerId);
  const pairUrl = `${window.location.origin}/?as=${getOtherPlayerId()}&join=${s.config.inviteCode}`;
  const pushSubscribed = Boolean(s.pushEnabledByPlayer[me.id]);

  openModal(`
    <div class="card-title-row">
      <h3 style="margin:0">⚙️ Settings & Phone Pairing</h3>
      <button class="action-chip" id="close-modal-btn">✕</button>
    </div>

    <div class="form-group">
      <label>Invite & Pair Friend's Phone (Code: ${esc(s.config.inviteCode)})</label>
      <div style="display:flex;gap:6px">
        <input type="text" readonly value="${esc(pairUrl)}" id="pair-url-input" style="flex:1;font-size:0.78rem" />
        <button class="action-chip" id="copy-pair-btn">Copy</button>
      </div>
    </div>

    <div class="form-group" style="background:#EFF6FF;padding:12px;border-radius:14px">
      <label style="color:#1D4ED8">🔔 Phone Push Notifications (${esc(me.name)})</label>
      <div style="font-size:0.76rem;color:#1E40AF;margin-bottom:8px">
        On iPhone, tap <strong>Share → Add to Home Screen</strong> first, then enable notifications here so taunts & proof challenges buzz your phone.
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn-primary" style="flex:1;background:#2563EB" id="enable-push-btn">
          ${pushSubscribed ? '✅ Push Enabled (Re-sync)' : '🔔 Enable Notifications'}
        </button>
        <button class="btn-secondary" style="width:auto" id="test-push-btn">Test Buzz</button>
      </div>
    </div>

    <div class="form-group">
      <label>Your Profile (${esc(me.name)})</label>
      <div style="display:grid;grid-template-columns:1fr 76px;gap:8px">
        <input id="prof-name" type="text" value="${esc(me.name)}" />
        <input id="prof-emoji" type="text" value="${esc(me.emoji)}" style="text-align:center" />
      </div>
    </div>
    <div class="form-group">
      <label>Your Signature Color (Updates Scoreboard & Calendar Heatmap)</label>
      <div class="color-picker-row">
        ${COLOR_PALETTE.map(
          (c) => `<button class="color-dot ${me.color.toLowerCase() === c.hex.toLowerCase() ? 'selected' : ''}" style="background:${c.hex}" data-pick-color="${c.hex}" title="${c.name}"></button>`
        ).join('')}
      </div>
    </div>

    <div class="form-group">
      <label>Season Weekly Base Point Budget (${s.config.weeklyBaseBudget} pts/wk)</label>
      <input id="season-budget-input" type="number" min="20" max="60" value="${s.config.weeklyBaseBudget}" />
    </div>

    <button class="btn-primary" id="save-settings-btn" style="margin-bottom:12px">Save Changes</button>

    <div style="border-top:1px solid var(--border);padding-top:12px;display:flex;flex-direction:column;gap:8px">
      <div class="section-label">Testing & Season Controls</div>
      <button class="btn-secondary" id="new-season-btn">🆕 Start New 4-Week Season (Open Transfer Window)</button>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <button class="btn-secondary" id="reset-fresh-btn">🧹 Clean Day 1</button>
        <button class="btn-secondary" id="reset-demo-btn">🎬 Restore Demo</button>
      </div>
    </div>
  `);

  let chosenColor = me.color;
  document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
  document.querySelectorAll('[data-pick-color]').forEach((btn) =>
    btn.addEventListener('click', () => {
      chosenColor = btn.dataset.pickColor;
      document.querySelectorAll('[data-pick-color]').forEach((b) => b.classList.remove('selected'));
      btn.classList.add('selected');
    })
  );

  document.getElementById('copy-pair-btn')?.addEventListener('click', async () => {
    await navigator.clipboard?.writeText(pairUrl);
    showToast('Invite link copied! Send it to your friend 📱');
  });

  document.getElementById('enable-push-btn')?.addEventListener('click', enableWebPush);
  document.getElementById('test-push-btn')?.addEventListener('click', async () => {
    const res = await api('/api/push/test', { playerId: ui.activePlayerId });
    showToast(res.sent > 0 ? 'Test buzz sent! 🔔' : 'Enable notifications on a real phone/browser first.');
  });

  document.getElementById('save-settings-btn')?.addEventListener('click', async () => {
    await api('/api/player', {
      playerId: ui.activePlayerId,
      name: document.getElementById('prof-name').value,
      emoji: document.getElementById('prof-emoji').value,
      color: chosenColor,
    });
    const newBudget = Number(document.getElementById('season-budget-input').value);
    if (newBudget !== s.config.weeklyBaseBudget) {
      await api('/api/season/settings', { weeklyBaseBudget: newBudget });
    }
    closeModal();
    showToast('Profile & settings updated! ✨');
  });

  document.getElementById('new-season-btn')?.addEventListener('click', async () => {
    await api('/api/season/settings', { startNewSeason: true });
    closeModal();
    ui.tab = 'lineup';
    render();
    showToast('New 4-Week Season started! Transfer Window is open.');
  });

  document.getElementById('reset-fresh-btn')?.addEventListener('click', async () => {
    await api('/api/reset-fresh', {});
    closeModal();
    showToast('Reset to clean Day 1! Ready for you & your friend.');
  });

  document.getElementById('reset-demo-btn')?.addEventListener('click', async () => {
    await api('/api/reset-demo', {});
    closeModal();
    showToast('Demo 4-week season restored!');
  });
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

async function enableWebPush() {
  try {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      showToast('Push notifications require HTTPS / Add to Home Screen on iOS.');
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') {
      showToast('Notification permission was declined.');
      return;
    }
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(ui.state.config.vapidPublicKey),
    });
    await api('/api/push/subscribe', { playerId: ui.activePlayerId, subscription: sub.toJSON() });
    showToast('Push notifications enabled! 🔔');
  } catch (err) {
    showToast(`Push setup note: ${err.message}`);
  }
}

// ---------- Event Binding ----------
function bindTabEvents() {
  // Matchday events
  document.querySelectorAll('[data-day]').forEach((btn) =>
    btn.addEventListener('click', () => {
      ui.selectedDay = btn.dataset.day;
      render();
    })
  );

  document.getElementById('edit-wager-card')?.addEventListener('click', () => {
    openModal(`
      <div class="card-title-row">
        <h3 style="margin:0">🤝 This Week's Friendly Wager</h3>
        <button class="action-chip" id="close-modal-btn">✕</button>
      </div>
      <div class="form-group">
        <label>What's on the line this week?</label>
        <input id="wager-input" type="text" value="${esc(ui.state.currentWeekMeta.wager_text)}" placeholder="e.g. Loser buys flat whites" />
      </div>
      <button class="btn-primary" id="save-wager-btn">Save Wager</button>
    `);
    document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
    document.getElementById('save-wager-btn')?.addEventListener('click', async () => {
      await api('/api/wager', { wagerText: document.getElementById('wager-input').value });
      closeModal();
      showToast('Weekly wager locked in! 🤝');
    });
  });

  document.querySelectorAll('[data-action="checkin"]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const dayStr = ui.selectedDay === 'today' ? ui.state.todayStr : ui.state.yesterdayStr;
      try {
        await api('/api/checkin', {
          habitId: btn.dataset.habit,
          playerId: ui.activePlayerId,
          dateStr: dayStr,
          status: btn.dataset.status,
        });
        if (btn.dataset.status === 'completed') launchConfetti(getPlayer(ui.activePlayerId).color);
      } catch (err) {
        showToast(err.message);
      }
    })
  );

  document.querySelectorAll('[data-action="checkin-numeric-quick"]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const dayStr = ui.selectedDay === 'today' ? ui.state.todayStr : ui.state.yesterdayStr;
      try {
        await api('/api/checkin', {
          habitId: btn.dataset.habit,
          playerId: ui.activePlayerId,
          dateStr: dayStr,
          status: 'completed',
          numericValue: Number(btn.dataset.target),
        });
        launchConfetti(getPlayer(ui.activePlayerId).color);
      } catch (err) {
        showToast(err.message);
      }
    })
  );

  document.querySelectorAll('[data-action="save-numeric"]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const dayStr = ui.selectedDay === 'today' ? ui.state.todayStr : ui.state.yesterdayStr;
      const val = Number(document.getElementById(`num-input-${btn.dataset.habit}`).value || 0);
      try {
        await api('/api/checkin', {
          habitId: btn.dataset.habit,
          playerId: ui.activePlayerId,
          dateStr: dayStr,
          numericValue: val,
        });
        const h = ui.state.habits.find((x) => x.id === btn.dataset.habit);
        if (h && val >= h.target_value) launchConfetti(getPlayer(ui.activePlayerId).color);
        else showToast('Progress saved!');
      } catch (err) {
        showToast(err.message);
      }
    })
  );

  document.querySelectorAll('[data-action="toggle-dd"]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const dayStr = ui.selectedDay === 'today' ? ui.state.todayStr : ui.state.yesterdayStr;
      try {
        const action = btn.dataset.active === '1' ? 'cancel' : 'activate';
        await api('/api/double-down', {
          habitId: btn.dataset.habit,
          playerId: ui.activePlayerId,
          dateStr: dayStr,
          action,
        });
        showToast(action === 'activate' ? '🎲 DOUBLE DOWN LIVE! Hit it for 2x pts!' : 'Double Down cancelled.');
      } catch (err) {
        showToast(err.message);
      }
    })
  );

  document.querySelectorAll('[data-action="open-note"]').forEach((btn) =>
    btn.addEventListener('click', () => openNotePhotoModal(btn.dataset.habit))
  );

  // Calendar events
  document.getElementById('cal-prev')?.addEventListener('click', () => {
    ui.calendarMonth = shiftMonth(ui.calendarMonth, -1);
    fetchState();
  });
  document.getElementById('cal-next')?.addEventListener('click', () => {
    ui.calendarMonth = shiftMonth(ui.calendarMonth, 1);
    fetchState();
  });
  document.querySelectorAll('[data-cal-mode]').forEach((btn) =>
    btn.addEventListener('click', () => {
      ui.calendarMode = btn.dataset.calMode;
      render();
    })
  );
  document.querySelectorAll('[data-solo-p]').forEach((btn) =>
    btn.addEventListener('click', () => {
      ui.calendarSoloPlayer = btn.dataset.soloP;
      render();
    })
  );
  document.querySelectorAll('[data-cal-date]').forEach((btn) =>
    btn.addEventListener('click', () => openDayDetailModal(btn.dataset.calDate))
  );

  // Feed events
  document.querySelectorAll('[data-quick-taunt]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const [emoji, text] = btn.dataset.quickTaunt.split('|');
      await api('/api/feed/taunt', { actorId: ui.activePlayerId, emoji, text });
      showToast('Banter sent! 🔥');
    })
  );

  document.getElementById('custom-taunt-btn')?.addEventListener('click', () => {
    openModal(`
      <div class="card-title-row">
        <h3 style="margin:0">💬 Send Friendly Banter</h3>
        <button class="action-chip" id="close-modal-btn">✕</button>
      </div>
      <div class="form-group">
        <label>Message to ${esc(getPlayer(getOtherPlayerId()).name)}</label>
        <textarea id="taunt-text" rows="3" placeholder="e.g. Hope you stretched before that Double Down 😄"></textarea>
      </div>
      <button class="btn-primary" id="send-taunt-btn">Send Nudge</button>
    `);
    document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
    document.getElementById('send-taunt-btn')?.addEventListener('click', async () => {
      await api('/api/feed/taunt', {
        actorId: ui.activePlayerId,
        emoji: '💬',
        text: document.getElementById('taunt-text').value,
      });
      closeModal();
      showToast('Sent!');
    });
  });

  document.querySelectorAll('[data-request-proof]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      try {
        await api('/api/proof/request', {
          actorId: ui.activePlayerId,
          checkinId: btn.dataset.requestProof,
          message: "Pics or it didn't happen! 📸",
        });
        showToast('Challenge fired! 📸');
      } catch (err) {
        showToast(err.message);
      }
    })
  );

  document.querySelectorAll('[data-reply-proof]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const evId = btn.dataset.replyProof;
      openModal(`
        <div class="card-title-row">
          <h3 style="margin:0">📸 Bring the Receipts!</h3>
          <button class="action-chip" id="close-modal-btn">✕</button>
        </div>
        <div class="form-group">
          <label>Upload proof photo</label>
          <input type="file" id="proof-photo-file" accept="image/*" capture="environment" />
        </div>
        <div class="form-group">
          <label>Cheeky reply note</label>
          <input type="text" id="proof-reply-note" placeholder="Boom, told you I did it 💪" />
        </div>
        <button class="btn-primary" id="submit-proof-btn">Submit Proof ✅</button>
      `);
      document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
      document.getElementById('submit-proof-btn')?.addEventListener('click', async () => {
        const file = document.getElementById('proof-photo-file').files[0];
        const photoDataUrl = file ? await readImageAsDataUrl(file) : '';
        await api('/api/proof/submit', {
          eventId: evId,
          actorId: ui.activePlayerId,
          note: document.getElementById('proof-reply-note').value,
          photoDataUrl,
        });
        closeModal();
        launchConfetti('#10B981');
        showToast('Receipts delivered! ✅');
      });
    })
  );

  // Lineup events
  document.getElementById('add-habit-btn')?.addEventListener('click', openAddHabitModal);
  document.getElementById('approve-season-btn')?.addEventListener('click', async () => {
    await api('/api/season/approve', { playerId: ui.activePlayerId });
    showToast('Lineup approved! 👍');
  });
  document.getElementById('open-transfer-btn')?.addEventListener('click', async () => {
    await api('/api/season/settings', { transferWindowOpen: true });
    showToast('4-Week Transfer Window opened!');
  });
  document.querySelectorAll('[data-approve-habit]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api(`/api/habits/${btn.dataset.approveHabit}/approve`, {});
      showToast('Habit approved! ⚖️');
    })
  );
  document.querySelectorAll('[data-delete-habit]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api(`/api/habits/${btn.dataset.deleteHabit}/delete`, {});
      showToast('Habit removed.');
    })
  );

  // Trophies events
  document.querySelectorAll('[data-toggle-paid]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api('/api/wager', {
        weekStart: btn.dataset.togglePaid,
        wagerPaid: btn.dataset.paid !== '1',
      });
    })
  );
  document.getElementById('add-milestone-btn')?.addEventListener('click', () => {
    openModal(`
      <div class="card-title-row">
        <h3 style="margin:0">🎁 Add Duo Flame Milestone</h3>
        <button class="action-chip" id="close-modal-btn">✕</button>
      </div>
      <div class="form-group">
        <label>Reward Title</label>
        <input id="ms-title" type="text" placeholder="e.g. Celebration dinner together" />
      </div>
      <div style="display:grid;grid-template-columns:1fr 80px;gap:8px">
        <div class="form-group">
          <label>Consecutive Duo Flame Weeks</label>
          <input id="ms-wks" type="number" min="1" value="6" />
        </div>
        <div class="form-group">
          <label>Emoji</label>
          <input id="ms-emoji" type="text" value="🍾" style="text-align:center" />
        </div>
      </div>
      <button class="btn-primary" id="save-ms-btn">Save Milestone</button>
    `);
    document.getElementById('close-modal-btn')?.addEventListener('click', closeModal);
    document.getElementById('save-ms-btn')?.addEventListener('click', async () => {
      await api('/api/milestones', {
        title: document.getElementById('ms-title').value,
        weeksRequired: Number(document.getElementById('ms-wks').value),
        emoji: document.getElementById('ms-emoji').value,
      });
      closeModal();
      showToast('Milestone added! 🔥');
    });
  });
  document.querySelectorAll('[data-del-ms]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await api('/api/milestones', { deleteId: btn.dataset.delMs });
    })
  );
}

// ---------- Topbar & Nav Listeners ----------
document.querySelectorAll('.nav-item').forEach((btn) =>
  btn.addEventListener('click', () => {
    ui.tab = btn.dataset.tab;
    render();
  })
);

document.getElementById('player-switch-btn').addEventListener('click', () => {
  ui.activePlayerId = getOtherPlayerId();
  localStorage.setItem('rivalup_player', ui.activePlayerId);
  applyThemeColors();
  render();
  showToast(`Switched view to ${getPlayer(ui.activePlayerId).name}`);
});

document.getElementById('settings-btn').addEventListener('click', openSettingsModal);

// Register Service Worker & Boot
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}
fetchState();
connectSSE();
