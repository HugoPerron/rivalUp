# ⚡ RivalUp — 1v1 Gamified Habit Competition (PWA)

A mobile-first 1v1 habit competition app built for two competitive friends — designed to be fierce on the scoreboard and uplifting in spirit.

## Features Built
* **Weekly Matches + 4-Week Seasons:** Fresh scoreboard every Monday, long-term habits carry over automatically, and a **4-Week Transfer Window** lets you update lineups & approve difficulty tiers together.
* **40-Point Weekly Salary Cap:** Both players build personal + shared habits up to the exact same base point budget (default `40 pts/wk`, adjustable `20–60`).
* **All 4 Habit Types:** Daily yes/no, Weekly frequency (`3x/wk`), Numeric targets (`10,000 steps`, `20 min`), and Avoid habits (`Held Strong / Slipped`).
* **Morning Grace Period:** Yesterday stays open for logging until **12:00 PM (noon)** the next day, then locks permanently.
* **Competitive Twists:** Shared Head-to-Head bonus (`+1 pt`), Hot-Streak multiplier (`+1 pt` on Day 3+ or hitting weekly goal), **Double Down** (`2x` base points if hit, `-1 pt` if missed, 2 tokens/week), and auto-tracked **Weekly Mystery Side-Quest** (`+4 pts`).
* **Good-Spirits Co-op:** **Duo Flame Streak** grows when *both* players hit ≥75% of their weekly base budget, unlocking custom real-life milestones (plus Weekly Wagers & Paid tracker).
* **Shared Dual-Color Calendar Heatmap:** Diagonal split-color calendar tiles (each player's signature color scaled by daily points, ⭐ gold border when both score 5+ pts), Daily Winner map, Solo 12-week heatmap, and tap-any-day breakdown.
* **Banter & Accountability:** Fast 1-tap check-ins, optional photo/notes, quick Cheers/Taunts, **"Pics or it didn't happen"** proof challenges (3/week), and **real Web Push Notifications**.

---

## Run Locally (Zero Dependencies — Node 24+)

```bash
cd ~/rivalup-app
npm start
```

Open `http://localhost:3456` in your browser. Use the **Player Switcher pill** in the top-right (`⚡ Hugo ⇄`) to test both sides instantaneously, or open **Settings ⚙️ → Clean Day 1** when you're ready to start fresh with your friend.

Run the scoring & math verification suite:

```bash
npm test
```

---

## Put It On Both Personal Phones (Free Public Hosting in ~5 Minutes)

Because **RivalUp** has **zero external npm packages** and stores everything in a local SQLite file (`data/rivalup.db`), it deploys effortlessly to any free Node hosting provider with HTTPS (HTTPS is required for iPhone/Android "Add to Home Screen" & Push Notifications):

1. Push the `~/rivalup-app` folder to a **private GitHub repo**.
2. Connect that repo to **Render.com**, **Railway.app**, or **Fly.io** (choose Node 22/24, Start command: `npm start`, attach a tiny persistent volume mounted at `/app/data` and `/app/uploads` so your match history & photos stay saved across restarts).
3. Open your live `https://...` link on both personal phones:
   * **On iPhone (Safari):** Tap **Share → Add to Home Screen** → open RivalUp from your Home Screen → tap **⚙️ Settings → Enable Notifications**.
   * **On Android (Chrome):** Tap the browser menu **Install App / Add to Home Screen** → open RivalUp → tap **⚙️ Settings → Enable Notifications**.
4. Tap **⚙️ Settings → Copy Invite Link** to pair your friend's phone straight into Player 2!
