import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculatePlayerWeeklyBudget,
  getDateEditability,
  scorePlayerWeek,
  resolveWeekMatch,
  buildHeatmapDays,
  addDays,
} from '../src/scoring.mjs';

const SAMPLE_HABITS = [
  { id: 'sh_gym', owner_id: 'shared', title: 'Workout', kind: 'check', cadence: 'weekly', target_count: 3, target_value: 1, difficulty: 3, active: 1, approval_status: 'approved' }, // 9
  { id: 'sh_steps', owner_id: 'shared', title: '10k Steps', kind: 'numeric', cadence: 'daily', target_count: 7, target_value: 10000, difficulty: 2, active: 1, approval_status: 'approved' }, // 14
  { id: 'p1_pol', owner_id: 'p1', title: 'Polish', kind: 'numeric', cadence: 'daily', target_count: 7, target_value: 20, difficulty: 1, active: 1, approval_status: 'approved' }, // 7
  { id: 'p1_scr', owner_id: 'p1', title: 'No Scroll', kind: 'avoid', cadence: 'weekly', target_count: 5, target_value: 1, difficulty: 2, active: 1, approval_status: 'approved' }, // 10
  { id: 'p2_rd', owner_id: 'p2', title: 'Read', kind: 'check', cadence: 'daily', target_count: 7, target_value: 1, difficulty: 1, active: 1, approval_status: 'approved' }, // 7
  { id: 'p2_sug', owner_id: 'p2', title: 'No Sugar', kind: 'avoid', cadence: 'weekly', target_count: 5, target_value: 1, difficulty: 2, active: 1, approval_status: 'approved' }, // 10
];

test('Salary cap budget equals exact 40 base pts/week for both players', () => {
  assert.equal(calculatePlayerWeeklyBudget(SAMPLE_HABITS, 'p1'), 40);
  assert.equal(calculatePlayerWeeklyBudget(SAMPLE_HABITS, 'p2'), 40);
});

test('Morning grace period allows yesterday before noon and locks at 12:00 PM', () => {
  const beforeNoon = new Date(2026, 10, 26, 11, 59, 0); // Nov 26, 11:59 AM
  const afterNoon = new Date(2026, 10, 26, 12, 0, 0); // Nov 26, 12:00 PM

  assert.equal(getDateEditability('2026-11-26', beforeNoon).editable, true);
  assert.equal(getDateEditability('2026-11-25', beforeNoon).editable, true);
  assert.equal(getDateEditability('2026-11-25', afterNoon).editable, false);
  assert.equal(getDateEditability('2026-11-24', beforeNoon).editable, false);
});

test('Scoring engine calculates Base, Shared, Hot Streak, Double Down (win & miss), Quest & Duo Flame accurately', () => {
  const weekStart = '2026-11-23'; // Monday
  const now = new Date(2026, 10, 26, 15, 0, 0); // Thursday 3 PM (Mon/Tue/Wed locked!)

  const checkins = [
    // Shared 10k Steps (Med=2, Shared=+1) on Mon, Tue, Wed -> 3-day streak gives +1 on Wed!
    { id: 'c1', habit_id: 'sh_steps', player_id: 'p1', date_str: '2026-11-23', status: 'completed', numeric_value: 10500 },
    { id: 'c2', habit_id: 'sh_steps', player_id: 'p1', date_str: '2026-11-24', status: 'completed', numeric_value: 11000 },
    { id: 'c3', habit_id: 'sh_steps', player_id: 'p1', date_str: '2026-11-25', status: 'completed', numeric_value: 10200 },
    // Shared Gym (Hard=3, Shared=+1, Weekly 3x) logged 4 times -> 4th caps out of base/shared, 3rd gets +1 weekly goal streak!
    { id: 'c4', habit_id: 'sh_gym', player_id: 'p1', date_str: '2026-11-23', status: 'completed' },
    { id: 'c5', habit_id: 'sh_gym', player_id: 'p1', date_str: '2026-11-24', status: 'completed' },
    { id: 'c6', habit_id: 'sh_gym', player_id: 'p1', date_str: '2026-11-25', status: 'completed' },
    { id: 'c7', habit_id: 'sh_gym', player_id: 'p1', date_str: '2026-11-26', status: 'completed' },
  ];

  const doubleDowns = [
    // WON Double Down on Mon Gym (+3 extra)
    { id: 'dd1', habit_id: 'sh_gym', player_id: 'p1', week_start: weekStart, date_str: '2026-11-23' },
    // MISSED Double Down on Mon Polish (already locked! -> -1 penalty)
    { id: 'dd2', habit_id: 'p1_pol', player_id: 'p1', week_start: weekStart, date_str: '2026-11-23' },
  ];

  const res = scorePlayerWeek({
    playerId: 'p1',
    weekStart,
    habits: SAMPLE_HABITS,
    checkins,
    doubleDowns,
    questId: 'high_roller', // Win a Double Down -> +4 pts!
    weeklyBaseBudget: 40,
    now,
  });

  // Base: 3*2 (steps) + 3*3 (gym capped at 3) = 15
  assert.equal(res.basePoints, 15);
  // Shared: 3*1 (steps) + 3*1 (gym capped at 3) = 6
  assert.equal(res.sharedBonus, 6);
  // Streak: +1 on Wed steps (day 3) + +1 on Wed gym (3/3 weekly target) = 2
  assert.equal(res.streakBonus, 2);
  // Double Down: +3 (won) - 1 (missed locked Mon) = +2
  assert.equal(res.doubleDownDelta, 2);
  // Quest (high_roller): +4
  assert.equal(res.questBonus, 4);
  // Total: 15 + 6 + 2 + 2 + 4 = 29
  assert.equal(res.totalPoints, 29);
  // Duo threshold for 40-pt budget = ceil(40 * 0.75) = 30
  assert.equal(res.duoThresholdPoints, 30);
  assert.equal(res.hitDuoThreshold, false);
});

test('Tie-breaker resolves Shared Bonus first, then Base Completion %, then Draw', () => {
  const m1 = resolveWeekMatch(
    { playerId: 'p1', totalPoints: 40, sharedBonus: 8, baseCompletionPct: 80, hitDuoThreshold: true },
    { playerId: 'p2', totalPoints: 40, sharedBonus: 6, baseCompletionPct: 85, hitDuoThreshold: true }
  );
  assert.equal(m1.winnerId, 'p1');
  assert.equal(m1.duoFlameEarned, true);

  const m2 = resolveWeekMatch(
    { playerId: 'p1', totalPoints: 40, sharedBonus: 6, baseCompletionPct: 75, hitDuoThreshold: true },
    { playerId: 'p2', totalPoints: 40, sharedBonus: 6, baseCompletionPct: 80, hitDuoThreshold: false }
  );
  assert.equal(m2.winnerId, 'p2');
  assert.equal(m2.duoFlameEarned, false);
});

test('Heatmap daily point totals match Matchday per-day totals', () => {
  const weekStart = '2026-11-23';
  const checkins = [
    { id: 'c1', habit_id: 'sh_gym', player_id: 'p1', date_str: '2026-11-23', status: 'completed' }, // 3 + 1 = 4
    { id: 'c2', habit_id: 'sh_steps', player_id: 'p1', date_str: '2026-11-23', status: 'completed', numeric_value: 10000 }, // 2 + 1 = 3 -> total 7
    { id: 'c3', habit_id: 'sh_gym', player_id: 'p2', date_str: '2026-11-23', status: 'completed' }, // 4
    { id: 'c4', habit_id: 'p2_rd', player_id: 'p2', date_str: '2026-11-23', status: 'completed' }, // 1 -> total 5
  ];

  const heatmap = buildHeatmapDays({
    startDate: weekStart,
    endDate: addDays(weekStart, 6),
    habits: SAMPLE_HABITS,
    checkins,
    doubleDowns: [],
    weeksMap: new Map(),
    weeklyBaseBudget: 40,
    now: new Date(2026, 10, 26, 15, 0, 0),
  });

  const day = heatmap['2026-11-23'];
  assert.equal(day.p1.totalPoints, 7);
  assert.equal(day.p2.totalPoints, 5);
  assert.equal(day.winner, 'p1');
  assert.equal(day.bothCrushed, true); // Both >= 5 pts!
});
