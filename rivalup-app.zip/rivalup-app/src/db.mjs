import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import path from 'node:path';
import {
  formatDateLocal,
  getWeekStart,
  addDays,
  pickQuestForWeek,
} from './scoring.mjs';
import { generateVapidKeys } from './push.mjs';

export function openDatabase(dbPath) {
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');

  db.exec(`
    CREATE TABLE IF NOT EXISTS match_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      invite_code TEXT NOT NULL,
      season_num INTEGER NOT NULL DEFAULT 1,
      season_start_week TEXT NOT NULL,
      weekly_base_budget INTEGER NOT NULL DEFAULT 40,
      transfer_window_open INTEGER NOT NULL DEFAULT 0,
      vapid_public_key TEXT NOT NULL,
      vapid_private_key_pem TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS players (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      emoji TEXT NOT NULL,
      color TEXT NOT NULL,
      approved_season INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS habits (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL, -- 'shared' | 'p1' | 'p2'
      title TEXT NOT NULL,
      kind TEXT NOT NULL, -- 'check' | 'numeric' | 'avoid'
      cadence TEXT NOT NULL, -- 'daily' | 'weekly'
      target_count INTEGER NOT NULL DEFAULT 7,
      target_value REAL NOT NULL DEFAULT 1,
      unit TEXT NOT NULL DEFAULT '',
      difficulty INTEGER NOT NULL DEFAULT 1,
      active INTEGER NOT NULL DEFAULT 1,
      approval_status TEXT NOT NULL DEFAULT 'approved', -- 'approved' | 'pending'
      proposed_by TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS checkins (
      id TEXT PRIMARY KEY,
      habit_id TEXT NOT NULL,
      player_id TEXT NOT NULL,
      date_str TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'completed', -- 'completed' | 'slipped'
      numeric_value REAL,
      note TEXT DEFAULT '',
      photo_url TEXT DEFAULT '',
      logged_at TEXT NOT NULL,
      UNIQUE(habit_id, player_id, date_str)
    );

    CREATE TABLE IF NOT EXISTS double_downs (
      id TEXT PRIMARY KEY,
      habit_id TEXT NOT NULL,
      player_id TEXT NOT NULL,
      week_start TEXT NOT NULL,
      date_str TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(habit_id, player_id, date_str)
    );

    CREATE TABLE IF NOT EXISTS weeks (
      week_start TEXT PRIMARY KEY,
      season_num INTEGER NOT NULL,
      week_in_season INTEGER NOT NULL,
      wager_text TEXT NOT NULL DEFAULT 'Loser buys flat whites ☕',
      wager_paid INTEGER NOT NULL DEFAULT 0,
      quest_id TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS feed_events (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL, -- 'checkin' | 'taunt' | 'reaction' | 'proof_request' | 'proof_reply' | 'double_down' | 'approval' | 'wager'
      actor_id TEXT NOT NULL,
      target_id TEXT,
      checkin_id TEXT,
      payload_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS milestones (
      id TEXT PRIMARY KEY,
      weeks_required INTEGER NOT NULL,
      title TEXT NOT NULL,
      emoji TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS push_subscriptions (
      id TEXT PRIMARY KEY,
      player_id TEXT NOT NULL,
      endpoint TEXT NOT NULL UNIQUE,
      p256dh TEXT NOT NULL,
      auth TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  const cfg = db.prepare('SELECT id FROM match_config WHERE id = 1').get();
  if (!cfg) {
    seedDemoData(db);
  }
  return db;
}

export function uid(prefix = 'id') {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

export function clearMatchData(db) {
  db.exec(`
    DELETE FROM checkins;
    DELETE FROM double_downs;
    DELETE FROM feed_events;
    DELETE FROM weeks;
    DELETE FROM habits;
    DELETE FROM milestones;
    DELETE FROM players;
  `);
}

function ensureConfig(db, { seasonStartWeek, transferWindowOpen = 0 }) {
  const existing = db.prepare('SELECT * FROM match_config WHERE id = 1').get();
  if (existing) {
    db.prepare(
      'UPDATE match_config SET season_num = 1, season_start_week = ?, weekly_base_budget = 40, transfer_window_open = ? WHERE id = 1'
    ).run(seasonStartWeek, transferWindowOpen);
    return;
  }
  const vapid = generateVapidKeys();
  const code = `RIVAL-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
  db.prepare(`
    INSERT INTO match_config (id, invite_code, season_num, season_start_week, weekly_base_budget, transfer_window_open, vapid_public_key, vapid_private_key_pem)
    VALUES (1, ?, 1, ?, 40, ?, ?, ?)
  `).run(code, seasonStartWeek, transferWindowOpen, vapid.publicKey, vapid.privateKeyPem);
}

/** Seed a clean Day 1 match ready for real use (keeps 40-pt starter templates & Transfer Window open!). */
export function seedFreshData(db, now = new Date()) {
  const todayStr = formatDateLocal(now);
  const currentWeek = getWeekStart(todayStr);
  clearMatchData(db);
  ensureConfig(db, { seasonStartWeek: currentWeek, transferWindowOpen: 1 });

  const insPlayer = db.prepare('INSERT INTO players (id, name, emoji, color, approved_season) VALUES (?, ?, ?, ?, ?)');
  insPlayer.run('p1', 'Hugo', '⚡', '#2563EB', 0);
  insPlayer.run('p2', 'Friend', '🔥', '#F97316', 0);

  const nowIso = now.toISOString();
  const insHabit = db.prepare(`
    INSERT INTO habits (id, owner_id, title, kind, cadence, target_count, target_value, unit, difficulty, active, approval_status, proposed_by, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'approved', ?, ?)
  `);
  // Balanced 40-pt starter lineup (easily edited during Season 1 Transfer Window!)
  insHabit.run('h_shared_gym', 'shared', 'Workout / Gym', 'check', 'weekly', 3, 1, '', 3, 'p1', nowIso); // 9 pts
  insHabit.run('h_shared_steps', 'shared', '10,000 Steps', 'numeric', 'daily', 7, 10000, 'steps', 2, 'p1', nowIso); // 14 pts
  insHabit.run('h_p1_polish', 'p1', 'Study Polish (20 min)', 'numeric', 'daily', 7, 20, 'min', 1, 'p1', nowIso); // 7 pts
  insHabit.run('h_p1_scroll', 'p1', 'No Doomscrolling After 10pm', 'avoid', 'weekly', 5, 1, '', 2, 'p1', nowIso); // 10 pts
  insHabit.run('h_p2_read', 'p2', 'Read 15 Pages', 'check', 'daily', 7, 1, '', 1, 'p2', nowIso); // 7 pts
  insHabit.run('h_p2_sugar', 'p2', 'No Sugary Snacks', 'avoid', 'weekly', 5, 1, '', 2, 'p2', nowIso); // 10 pts

  const quest = pickQuestForWeek(currentWeek);
  db.prepare(`
    INSERT INTO weeks (week_start, season_num, week_in_season, wager_text, wager_paid, quest_id)
    VALUES (?, 1, 1, 'Loser buys flat whites ☕', 0, ?)
  `).run(currentWeek, quest.id);

  const insMs = db.prepare('INSERT INTO milestones (id, weeks_required, title, emoji) VALUES (?, ?, ?, ?)');
  insMs.run('ms_1', 2, 'Coffee & Pastries On Us', '🥐');
  insMs.run('ms_2', 4, 'Celebration Dinner Together', '🍽️');
  insMs.run('ms_3', 8, 'Weekend Day Trip', '🏔️');

  db.prepare(`
    INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
    VALUES (?, 'taunt', 'p1', 'p2', NULL, ?, ?)
  `).run(uid('ev'), JSON.stringify({ text: 'Season 1 Transfer Window is open! Check our 40-pt lineups and lock in!' }), nowIso);
}

/** Seed a lively mid-season match (3 completed weeks + current Week 4) so Heatmap, Trophies, Duo Flame & Feed shine immediately. */
export function seedDemoData(db, now = new Date()) {
  const todayStr = formatDateLocal(now);
  const currentWeek = getWeekStart(todayStr);
  const seasonStartWeek = addDays(currentWeek, -21); // Week 1 was 3 weeks ago; we are in Week 4 of Season 1!

  clearMatchData(db);
  ensureConfig(db, { seasonStartWeek, transferWindowOpen: 0 });

  const insPlayer = db.prepare('INSERT INTO players (id, name, emoji, color, approved_season) VALUES (?, ?, ?, ?, ?)');
  insPlayer.run('p1', 'Hugo', '⚡', '#2563EB', 1);
  insPlayer.run('p2', 'Alex', '🔥', '#F97316', 1);

  const nowIso = now.toISOString();
  const insHabit = db.prepare(`
    INSERT INTO habits (id, owner_id, title, kind, cadence, target_count, target_value, unit, difficulty, active, approval_status, proposed_by, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'approved', ?, ?)
  `);

  // Exact 40 base pts/week each:
  // Shared: Workout 3x/wk (3*3=9) + 10k Steps daily (2*7=14) = 23 pts
  // Personal: Easy daily (1*7=7) + Medium avoid 5x/wk (2*5=10) = 17 pts -> Total = 40 pts each!
  insHabit.run('h_shared_gym', 'shared', 'Workout / Gym', 'check', 'weekly', 3, 1, '', 3, 'p1', nowIso);
  insHabit.run('h_shared_steps', 'shared', '10,000 Steps', 'numeric', 'daily', 7, 10000, 'steps', 2, 'p1', nowIso);
  insHabit.run('h_p1_polish', 'p1', 'Study Polish (20 min)', 'numeric', 'daily', 7, 20, 'min', 1, 'p1', nowIso);
  insHabit.run('h_p1_scroll', 'p1', 'No Doomscrolling After 10pm', 'avoid', 'weekly', 5, 1, '', 2, 'p1', nowIso);
  insHabit.run('h_p2_read', 'p2', 'Read 15 Pages', 'check', 'daily', 7, 1, '', 1, 'p2', nowIso);
  insHabit.run('h_p2_sugar', 'p2', 'No Sugary Snacks', 'avoid', 'weekly', 5, 1, '', 2, 'p2', nowIso);

  const wagers = [
    { text: 'Loser buys specialty flat whites ☕', paid: 1, quest: 'clean_sweep' },
    { text: 'Loser picks the Friday lunch spot 🍜', paid: 1, quest: 'shared_dominance' },
    { text: 'Loser sends a dramatic 30s concession voice note 🎤', paid: 0, quest: 'hat_trick' },
    { text: 'Loser buys post-run smoothies 🥤', paid: 0, quest: 'high_roller' },
  ];

  const insWeek = db.prepare(`
    INSERT INTO weeks (week_start, season_num, week_in_season, wager_text, wager_paid, quest_id)
    VALUES (?, 1, ?, ?, ?, ?)
  `);

  const insCheckin = db.prepare(`
    INSERT INTO checkins (id, habit_id, player_id, date_str, status, numeric_value, note, photo_url, logged_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, '', ?)
  `);
  const insDD = db.prepare(`
    INSERT INTO double_downs (id, habit_id, player_id, week_start, date_str, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  let recentAlexCheckinId = null;
  let recentHugoCheckinId = null;

  for (let w = 0; w < 4; w++) {
    const wkStart = addDays(seasonStartWeek, w * 7);
    insWeek.run(wkStart, w + 1, wagers[w].text, wagers[w].paid, wagers[w].quest);

    // Deterministic varied patterns across the 4 weeks so Heatmap looks super vibrant & realistic!
    // Week 0: Hugo edges Alex (both hit >=30 base -> Duo Flame!)
    // Week 1: Alex beats Hugo (both hit >=30 base -> Duo Flame!)
    // Week 2: Hugo wins a close nail-biter (both hit >=30 base -> 3-week Duo Flame streak!)
    // Week 3 (current week): Populate up to yesterday (plus a couple today) so Hugo can check in right away!
    for (let dIdx = 0; dIdx < 7; dIdx++) {
      const dStr = addDays(wkStart, dIdx);
      if (dStr > todayStr) continue;
      const isToday = dStr === todayStr;

      const ts = `${dStr}T18:30:00.000Z`;

      // --- HUGO (p1) ---
      if (!isToday) {
        // Gym on Mon, Wed, Fri (plus Sat if skipped Fri)
        if ((w === 0 && [0, 2, 4].includes(dIdx)) ||
            (w === 1 && [0, 3, 5].includes(dIdx)) ||
            (w === 2 && [0, 2, 4].includes(dIdx)) ||
            (w === 3 && [0, 2].includes(dIdx))) {
          const cid = uid('chk');
          insCheckin.run(cid, 'h_shared_gym', 'p1', dStr, 'completed', 1, dIdx === 2 ? 'Heavy leg day 🦵' : '', ts);
          recentHugoCheckinId = cid;
        }
        // Steps almost every day except a lazy Sunday in week 1
        if (!(w === 1 && dIdx === 6) && !(w === 0 && dIdx === 5)) {
          const steps = 10400 + ((w * 7 + dIdx) % 5) * 850;
          insCheckin.run(uid('chk'), 'h_shared_steps', 'p1', dStr, 'completed', steps, '', ts);
        }
        // Polish study
        if (!(w === 1 && dIdx === 4)) {
          insCheckin.run(uid('chk'), 'h_p1_polish', 'p1', dStr, 'completed', 25, '', ts);
        }
        // No doomscrolling (5x/wk: Mon-Fri mostly)
        if ([0, 1, 2, 3, 4].includes(dIdx) && !(w === 1 && dIdx === 3)) {
          insCheckin.run(uid('chk'), 'h_p1_scroll', 'p1', dStr, 'completed', 1, '', ts);
        }
      } else {
        // Today: log 1 morning habit for Hugo so Matchday still has plenty of juicy habits left to tap!
        insCheckin.run(uid('chk'), 'h_p1_polish', 'p1', dStr, 'completed', 20, 'Morning coffee + flashcards', nowIso);
      }

      // --- ALEX (p2) ---
      if (!isToday) {
        if ((w === 0 && [1, 3, 5].includes(dIdx)) ||
            (w === 1 && [0, 2, 4].includes(dIdx)) ||
            (w === 2 && [1, 3, 5].includes(dIdx)) ||
            (w === 3 && [0, 2].includes(dIdx))) {
          const cid = uid('chk');
          insCheckin.run(cid, 'h_shared_gym', 'p2', dStr, 'completed', 1, dIdx === 2 ? '5k tempo run — feeling fast 💨' : '', ts);
          recentAlexCheckinId = cid;
        }
        if (!(w === 0 && dIdx === 6) && !(w === 2 && dIdx === 4)) {
          const steps = 10800 + ((w * 5 + dIdx) % 4) * 900;
          insCheckin.run(uid('chk'), 'h_shared_steps', 'p2', dStr, 'completed', steps, '', ts);
        }
        if (!(w === 0 && dIdx === 3)) {
          insCheckin.run(uid('chk'), 'h_p2_read', 'p2', dStr, 'completed', 1, '', ts);
        }
        if ([0, 1, 2, 3, 5].includes(dIdx) && !(w === 2 && dIdx === 5)) {
          insCheckin.run(uid('chk'), 'h_p2_sugar', 'p2', dStr, 'completed', 1, '', ts);
        }
      } else {
        // Today: Alex already logged 10k steps & Reading to put friendly pressure on Hugo!
        const cid = uid('chk');
        insCheckin.run(cid, 'h_shared_steps', 'p2', dStr, 'completed', 11420, 'Lunch walk crushed it 🚶‍♂️', nowIso);
        recentAlexCheckinId = cid;
        insCheckin.run(uid('chk'), 'h_p2_read', 'p2', dStr, 'completed', 1, 'Finished two chapters', nowIso);
      }
    }

    // Add realistic Double Downs across weeks
    if (w === 0) {
      insDD.run(uid('dd'), 'h_shared_gym', 'p1', wkStart, addDays(wkStart, 4), nowIso);
      insDD.run(uid('dd'), 'h_shared_steps', 'p2', wkStart, addDays(wkStart, 2), nowIso);
    } else if (w === 1) {
      insDD.run(uid('dd'), 'h_shared_gym', 'p2', wkStart, addDays(wkStart, 4), nowIso);
      insDD.run(uid('dd'), 'h_shared_steps', 'p1', wkStart, addDays(wkStart, 6), nowIso); // missed Sunday -> -1!
    } else if (w === 2) {
      insDD.run(uid('dd'), 'h_shared_gym', 'p1', wkStart, addDays(wkStart, 2), nowIso);
      insDD.run(uid('dd'), 'h_shared_gym', 'p2', wkStart, addDays(wkStart, 3), nowIso);
    } else if (w === 3) {
      // Current week: Alex already used 1 Double Down on Monday gym (if today >= Mon)
      const monStr = wkStart;
      if (monStr < todayStr) {
        insDD.run(uid('dd'), 'h_shared_gym', 'p2', wkStart, monStr, nowIso);
      }
    }
  }

  const insMs = db.prepare('INSERT INTO milestones (id, weeks_required, title, emoji) VALUES (?, ?, ?, ?)');
  insMs.run('ms_1', 2, 'Coffee & Pastries On Us', '🥐');
  insMs.run('ms_2', 4, 'Celebration Dinner Together', '🍽️');
  insMs.run('ms_3', 8, 'Weekend Day Trip', '🏔️');

  const insFeed = db.prepare(`
    INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const t1 = new Date(now.getTime() - 3 * 3600000).toISOString();
  const t2 = new Date(now.getTime() - 2 * 3600000).toISOString();
  const t3 = new Date(now.getTime() - 45 * 60000).toISOString();
  const t4 = new Date(now.getTime() - 12 * 60000).toISOString();

  insFeed.run(
    uid('ev'),
    'checkin',
    'p1',
    null,
    recentHugoCheckinId,
    JSON.stringify({ habitTitle: 'Study Polish (20 min)', note: 'Morning coffee + flashcards', points: 2 }),
    t1
  );
  insFeed.run(
    uid('ev'),
    'checkin',
    'p2',
    null,
    recentAlexCheckinId,
    JSON.stringify({ habitTitle: '10,000 Steps', note: 'Lunch walk crushed it 🚶‍♂️', points: 4 }),
    t2
  );
  insFeed.run(
    uid('ev'),
    'taunt',
    'p2',
    'p1',
    null,
    JSON.stringify({ emoji: '👀', text: 'Already ahead on 10k steps today — hope you like buying smoothies 🥤' }),
    t3
  );
  if (recentHugoCheckinId) {
    insFeed.run(
      uid('ev'),
      'proof_request',
      'p2',
      'p1',
      recentHugoCheckinId,
      JSON.stringify({
        habitTitle: 'Workout / Gym',
        message: 'Pics or it didn\'t happen! Show me that gym selfie 💪',
        resolved: false,
      }),
      t4
    );
  }
}
