/**
 * RivalUp — Pure Scoring, Rules, Mystery Side-Quest & Calendar Heatmap Engine.
 * Zero external dependencies. Every formula is deterministic and itemized.
 */

export const DIFFICULTY_POINTS = {
  1: 1, // Easy
  2: 2, // Medium
  3: 3, // Hard
};

export const DIFFICULTY_LABELS = {
  1: 'Easy',
  2: 'Medium',
  3: 'Hard',
};

export const SHARED_BONUS_POINTS = 1;
export const HOT_STREAK_BONUS_POINTS = 1;
export const HOT_STREAK_MIN_DAYS = 3;
export const DOUBLE_DOWN_PENALTY = -1;
export const DOUBLE_DOWN_WEEKLY_TOKENS = 2;
export const PROOF_CHALLENGE_WEEKLY_TOKENS = 3;
export const SIDE_QUEST_BONUS_POINTS = 4;
export const DUO_FLAME_THRESHOLD_RATIO = 0.75;
export const GRACE_PERIOD_NOON_HOUR = 12;

export const MYSTERY_QUESTS = [
  {
    id: 'clean_sweep',
    title: 'Clean Sweep',
    emoji: '🧹',
    description: 'Complete 100% of your daily habits on any single day this week.',
    bonus: SIDE_QUEST_BONUS_POINTS,
  },
  {
    id: 'shared_dominance',
    title: 'Head-to-Head Hero',
    emoji: '⚔️',
    description: 'Log at least 4 shared habit check-ins across the week.',
    bonus: SIDE_QUEST_BONUS_POINTS,
  },
  {
    id: 'hat_trick',
    title: 'Double Flame',
    emoji: '🔥',
    description: 'Reach a 3+ day streak on at least 2 different habits this week.',
    bonus: SIDE_QUEST_BONUS_POINTS,
  },
  {
    id: 'high_roller',
    title: 'High Roller',
    emoji: '🎲',
    description: 'Activate and successfully win a Double Down bet this week.',
    bonus: SIDE_QUEST_BONUS_POINTS,
  },
  {
    id: 'weekend_warrior',
    title: 'Weekend Warrior',
    emoji: '🛡️',
    description: 'Score at least 8 base points across Saturday and Sunday.',
    bonus: SIDE_QUEST_BONUS_POINTS,
  },
];

// ---------- Date Helpers (YYYY-MM-DD in local time) ----------

export function formatDateLocal(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseDateLocal(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d, 12, 0, 0, 0);
}

export function addDays(dateStr, delta) {
  const d = parseDateLocal(dateStr);
  d.setDate(d.getDate() + delta);
  return formatDateLocal(d);
}

export function diffDays(startStr, endStr) {
  const a = parseDateLocal(startStr);
  const b = parseDateLocal(endStr);
  return Math.round((b - a) / 86400000);
}

/** Returns Monday YYYY-MM-DD for the ISO week containing dateStr. */
export function getWeekStart(dateStr) {
  const d = parseDateLocal(dateStr);
  const day = d.getDay(); // 0=Sun, 1=Mon ... 6=Sat
  const offset = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + offset);
  return formatDateLocal(d);
}

export function getWeekDates(weekStart) {
  return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
}

/**
 * Morning grace period rule:
 * - Today is always editable.
 * - Yesterday is editable while now.getHours() < 12 (before noon).
 * - Future dates and anything older than yesterday are locked.
 */
export function getDateEditability(dateStr, now = new Date()) {
  const todayStr = formatDateLocal(now);
  const yesterdayStr = addDays(todayStr, -1);

  if (dateStr === todayStr) {
    return { editable: true, reason: 'open_today', label: 'Open today' };
  }
  if (dateStr === yesterdayStr) {
    if (now.getHours() < GRACE_PERIOD_NOON_HOUR) {
      return {
        editable: true,
        reason: 'grace_period',
        label: 'Morning grace — open until 12:00 PM',
      };
    }
    return {
      editable: false,
      reason: 'locked_noon',
      label: 'Locked at 12:00 PM today',
    };
  }
  if (dateStr > todayStr) {
    return { editable: false, reason: 'future', label: 'Upcoming day' };
  }
  return { editable: false, reason: 'locked_past', label: 'Locked' };
}

/** Check if a habit belongs to a player (either personal or shared). */
export function habitAppliesToPlayer(habit, playerId) {
  return habit.owner_id === 'shared' || habit.owner_id === playerId;
}

/** Weekly max base points for a single habit. */
export function habitWeeklyBudget(habit) {
  const pts = DIFFICULTY_POINTS[habit.difficulty] || 1;
  const count = habit.cadence === 'daily' ? 7 : Math.max(1, Number(habit.target_count || 1));
  return pts * count;
}

/** Total weekly base point budget for a player's active approved (or pending) habits. */
export function calculatePlayerWeeklyBudget(habits, playerId, { includePending = false } = {}) {
  return habits
    .filter((h) => h.active && habitAppliesToPlayer(h, playerId) && (includePending || h.approval_status === 'approved'))
    .reduce((sum, h) => sum + habitWeeklyBudget(h), 0);
}

/** Compute consecutive streak length up to and including `dateStr` for a daily habit. */
export function computeConsecutiveStreak(habitId, playerId, dateStr, completedSet) {
  let streak = 0;
  let cursor = dateStr;
  while (completedSet.has(`${habitId}|${playerId}|${cursor}`)) {
    streak += 1;
    cursor = addDays(cursor, -1);
    if (streak > 365) break;
  }
  return streak;
}

/** Pick deterministic Mystery Side-Quest for a week if none stored. */
export function getQuestById(questId) {
  return MYSTERY_QUESTS.find((q) => q.id === questId) || MYSTERY_QUESTS[0];
}

export function pickQuestForWeek(weekStart) {
  const hash = weekStart.split('').reduce((acc, ch) => acc * 31 + ch.charCodeAt(0), 7);
  return MYSTERY_QUESTS[Math.abs(hash) % MYSTERY_QUESTS.length];
}

/**
 * Evaluate a single player's complete itemized score for a Mon–Sun week.
 */
export function scorePlayerWeek({
  playerId,
  weekStart,
  habits,
  checkins,
  doubleDowns,
  questId,
  weeklyBaseBudget = 40,
  now = new Date(),
}) {
  const weekDates = getWeekDates(weekStart);
  const weekDateSet = new Set(weekDates);
  const todayStr = formatDateLocal(now);

  const playerHabits = habits.filter(
    (h) => h.active && habitAppliesToPlayer(h, playerId) && h.approval_status === 'approved'
  );
  const habitById = new Map(playerHabits.map((h) => [h.id, h]));

  // Build lookup of ALL completed checkins across history (needed for cross-week streaks!)
  const completedSet = new Set();
  for (const c of checkins) {
    if (c.player_id === playerId && c.status === 'completed') {
      completedSet.add(`${c.habit_id}|${playerId}|${c.date_str}`);
    }
  }

  // Group this week's checkins by habit and by date
  const weekCheckins = checkins
    .filter((c) => c.player_id === playerId && weekDateSet.has(c.date_str) && habitById.has(c.habit_id))
    .sort((a, b) => a.date_str.localeCompare(b.date_str));

  const ddMap = new Map();
  const weekDDs = doubleDowns.filter((d) => d.player_id === playerId && d.week_start === weekStart);
  for (const dd of weekDDs) {
    ddMap.set(`${dd.habit_id}|${dd.date_str}`, dd);
  }

  // Track weekly-cadence completions count per habit (so base & shared points cap at target_count)
  const weeklyCompletionCounts = new Map();
  const perDay = {};
  for (const d of weekDates) {
    perDay[d] = {
      date: d,
      basePoints: 0,
      sharedBonus: 0,
      streakBonus: 0,
      doubleDownDelta: 0,
      totalPoints: 0,
      completedCount: 0,
      items: [],
    };
  }

  let basePoints = 0;
  let sharedBonus = 0;
  let streakBonus = 0;
  let doubleDownDelta = 0;
  let sharedHabitsCompleted = 0;
  let doubleDownsWon = 0;
  let doubleDownsLost = 0;
  const habitsWith3DayStreakThisWeek = new Set();

  for (const c of weekCheckins) {
    const habit = habitById.get(c.habit_id);
    if (!habit || c.status !== 'completed') continue;

    const diffPts = DIFFICULTY_POINTS[habit.difficulty] || 1;
    const isShared = habit.owner_id === 'shared';
    const dayBucket = perDay[c.date_str];

    let earnedBase = 0;
    let earnedShared = 0;
    let earnedStreak = 0;
    let earnedDD = 0;
    let streakLen = 0;
    let withinWeeklyCap = true;

    if (habit.cadence === 'weekly') {
      const prevCount = weeklyCompletionCounts.get(habit.id) || 0;
      const newCount = prevCount + 1;
      weeklyCompletionCounts.set(habit.id, newCount);
      const target = Math.max(1, Number(habit.target_count || 1));
      withinWeeklyCap = newCount <= target;
      if (withinWeeklyCap) {
        earnedBase = diffPts;
        if (isShared) earnedShared = SHARED_BONUS_POINTS;
      }
      if (newCount === target) {
        earnedStreak = HOT_STREAK_BONUS_POINTS;
      }
      streakLen = newCount;
    } else {
      earnedBase = diffPts;
      if (isShared) earnedShared = SHARED_BONUS_POINTS;
      streakLen = computeConsecutiveStreak(habit.id, playerId, c.date_str, completedSet);
      if (streakLen >= HOT_STREAK_MIN_DAYS) {
        earnedStreak = HOT_STREAK_BONUS_POINTS;
        habitsWith3DayStreakThisWeek.add(habit.id);
      }
    }

    if (isShared) sharedHabitsCompleted += 1;

    const ddKey = `${habit.id}|${c.date_str}`;
    if (ddMap.has(ddKey) && withinWeeklyCap) {
      earnedDD = diffPts; // Doubles the base points (+diffPts extra)
      doubleDownsWon += 1;
    }

    basePoints += earnedBase;
    sharedBonus += earnedShared;
    streakBonus += earnedStreak;
    doubleDownDelta += earnedDD;

    dayBucket.basePoints += earnedBase;
    dayBucket.sharedBonus += earnedShared;
    dayBucket.streakBonus += earnedStreak;
    dayBucket.doubleDownDelta += earnedDD;
    dayBucket.totalPoints += earnedBase + earnedShared + earnedStreak + earnedDD;
    dayBucket.completedCount += 1;
    dayBucket.items.push({
      habitId: habit.id,
      title: habit.title,
      kind: habit.kind,
      isShared,
      difficulty: habit.difficulty,
      basePoints: earnedBase,
      sharedBonus: earnedShared,
      streakBonus: earnedStreak,
      doubleDownDelta: earnedDD,
      streakLen,
      withinWeeklyCap,
      numericValue: c.numeric_value,
      note: c.note,
      photoUrl: c.photo_url,
      checkinId: c.id,
    });
  }

  // Evaluate MISSED Double Down penalties (only once that day is locked!)
  const doubleDownStatuses = [];
  for (const dd of weekDDs) {
    const habit = habitById.get(dd.habit_id);
    if (!habit) continue;
    const isCompleted = completedSet.has(`${dd.habit_id}|${playerId}|${dd.date_str}`);
    const editInfo = getDateEditability(dd.date_str, now);
    if (isCompleted) {
      doubleDownStatuses.push({ ...dd, status: 'won', delta: DIFFICULTY_POINTS[habit.difficulty] || 1 });
    } else if (!editInfo.editable && dd.date_str <= todayStr) {
      doubleDownDelta += DOUBLE_DOWN_PENALTY;
      doubleDownsLost += 1;
      if (perDay[dd.date_str]) {
        perDay[dd.date_str].doubleDownDelta += DOUBLE_DOWN_PENALTY;
        perDay[dd.date_str].totalPoints += DOUBLE_DOWN_PENALTY;
      }
      doubleDownStatuses.push({ ...dd, status: 'lost', delta: DOUBLE_DOWN_PENALTY });
    } else {
      doubleDownStatuses.push({ ...dd, status: 'pending', delta: 0 });
    }
  }

  // Evaluate Weekly Mystery Side-Quest
  const quest = getQuestById(questId || pickQuestForWeek(weekStart).id);
  const questEval = evaluateMysteryQuest({
    quest,
    playerHabits,
    weekDates,
    perDay,
    completedSet,
    playerId,
    sharedHabitsCompleted,
    habitsWith3DayStreakCount: habitsWith3DayStreakThisWeek.size,
    doubleDownsWon,
  });

  const questBonus = questEval.completed ? quest.bonus : 0;
  const totalPoints = basePoints + sharedBonus + streakBonus + doubleDownDelta + questBonus;

  const actualBudget = calculatePlayerWeeklyBudget(habits, playerId);
  const effectiveCap = Math.max(1, weeklyBaseBudget || actualBudget || 40);
  const duoThresholdPoints = Math.ceil(effectiveCap * DUO_FLAME_THRESHOLD_RATIO);
  const baseCompletionPct = Math.round((basePoints / effectiveCap) * 100);
  const hitDuoThreshold = basePoints >= duoThresholdPoints;

  return {
    playerId,
    weekStart,
    basePoints,
    sharedBonus,
    streakBonus,
    doubleDownDelta,
    questBonus,
    totalPoints,
    weeklyBaseBudget: effectiveCap,
    actualLineupBudget: actualBudget,
    duoThresholdPoints,
    baseCompletionPct,
    hitDuoThreshold,
    sharedTotalScore: sharedHabitsCompleted,
    doubleDownsUsed: weekDDs.length,
    doubleDownsRemaining: Math.max(0, DOUBLE_DOWN_WEEKLY_TOKENS - weekDDs.length),
    doubleDownStatuses,
    quest: { ...quest, ...questEval },
    perDay,
  };
}

function evaluateMysteryQuest({
  quest,
  playerHabits,
  weekDates,
  perDay,
  completedSet,
  playerId,
  sharedHabitsCompleted,
  habitsWith3DayStreakCount,
  doubleDownsWon,
}) {
  switch (quest.id) {
    case 'clean_sweep': {
      const dailyHabits = playerHabits.filter((h) => h.cadence === 'daily');
      if (dailyHabits.length === 0) {
        return { completed: false, progress: 0, target: 1, label: 'Add a daily habit first' };
      }
      let bestDay = 0;
      let swept = false;
      for (const d of weekDates) {
        const done = dailyHabits.filter((h) => completedSet.has(`${h.id}|${playerId}|${d}`)).length;
        if (done > bestDay) bestDay = done;
        if (done === dailyHabits.length) swept = true;
      }
      return {
        completed: swept,
        progress: bestDay,
        target: dailyHabits.length,
        label: swept ? 'Completed!' : `Best day: ${bestDay}/${dailyHabits.length} daily habits`,
      };
    }
    case 'shared_dominance': {
      const target = 4;
      const done = Math.min(sharedHabitsCompleted, target);
      return {
        completed: sharedHabitsCompleted >= target,
        progress: done,
        target,
        label: `${sharedHabitsCompleted}/${target} shared check-ins`,
      };
    }
    case 'hat_trick': {
      const target = 2;
      const done = Math.min(habitsWith3DayStreakCount, target);
      return {
        completed: habitsWith3DayStreakCount >= target,
        progress: done,
        target,
        label: `${habitsWith3DayStreakCount}/${target} habits on a 3+ day streak`,
      };
    }
    case 'high_roller': {
      return {
        completed: doubleDownsWon >= 1,
        progress: Math.min(doubleDownsWon, 1),
        target: 1,
        label: doubleDownsWon >= 1 ? 'Double Down landed!' : '0/1 Double Down won',
      };
    }
    case 'weekend_warrior': {
      const sat = weekDates[5];
      const sun = weekDates[6];
      const wkndPts = (perDay[sat]?.basePoints || 0) + (perDay[sun]?.basePoints || 0);
      const target = 8;
      return {
        completed: wkndPts >= target,
        progress: Math.min(wkndPts, target),
        target,
        label: `${wkndPts}/${target} Sat+Sun base pts`,
      };
    }
    default:
      return { completed: false, progress: 0, target: 1, label: '' };
  }
}

/**
 * Determine the winner of a weekly match with exact tie-breaker rules:
 * 1) Total points
 * 2) Shared Head-to-Head habit points
 * 3) Base completion %
 * 4) Draw (Split Crown)
 */
export function resolveWeekMatch(p1Score, p2Score) {
  let winnerId = 'draw';
  let tieBreaker = null;

  if (p1Score.totalPoints !== p2Score.totalPoints) {
    winnerId = p1Score.totalPoints > p2Score.totalPoints ? p1Score.playerId : p2Score.playerId;
  } else if (p1Score.sharedBonus !== p2Score.sharedBonus) {
    winnerId = p1Score.sharedBonus > p2Score.sharedBonus ? p1Score.playerId : p2Score.playerId;
    tieBreaker = 'Won on Shared Head-to-Head bonus tie-breaker';
  } else if (p1Score.baseCompletionPct !== p2Score.baseCompletionPct) {
    winnerId = p1Score.baseCompletionPct > p2Score.baseCompletionPct ? p1Score.playerId : p2Score.playerId;
    tieBreaker = 'Won on higher Base Completion % tie-breaker';
  } else {
    winnerId = 'draw';
    tieBreaker = 'Exact tie — Split Crown!';
  }

  const duoFlameEarned = Boolean(p1Score.hitDuoThreshold && p2Score.hitDuoThreshold);

  return {
    winnerId,
    tieBreaker,
    duoFlameEarned,
    margin: Math.abs(p1Score.totalPoints - p2Score.totalPoints),
  };
}

/** Map a daily point total to intensity tier 0..4 for the heatmap. */
export function pointsToHeatLevel(points) {
  if (!points || points <= 0) return 0;
  if (points <= 2) return 1;
  if (points <= 5) return 2;
  if (points <= 8) return 3;
  return 4;
}

/**
 * Build daily heatmap dictionary across any date range [startDate..endDate].
 * Computes exact per-day points for both players so calendar tiles always match Matchday!
 */
export function buildHeatmapDays({
  startDate,
  endDate,
  habits,
  checkins,
  doubleDowns,
  weeksMap,
  weeklyBaseBudget,
  now = new Date(),
}) {
  const days = {};
  const firstWeek = getWeekStart(startDate);
  const lastWeek = getWeekStart(endDate);

  let cursorWeek = firstWeek;
  while (cursorWeek <= lastWeek) {
    const wkMeta = weeksMap.get(cursorWeek);
    const questId = wkMeta?.quest_id || pickQuestForWeek(cursorWeek).id;
    const s1 = scorePlayerWeek({
      playerId: 'p1',
      weekStart: cursorWeek,
      habits,
      checkins,
      doubleDowns,
      questId,
      weeklyBaseBudget,
      now,
    });
    const s2 = scorePlayerWeek({
      playerId: 'p2',
      weekStart: cursorWeek,
      habits,
      checkins,
      doubleDowns,
      questId,
      weeklyBaseBudget,
      now,
    });

    for (const d of getWeekDates(cursorWeek)) {
      if (d < startDate || d > endDate) continue;
      const d1 = s1.perDay[d];
      const d2 = s2.perDay[d];
      const p1Pts = d1.totalPoints;
      const p2Pts = d2.totalPoints;
      let winner = 'none';
      if (p1Pts > 0 || p2Pts > 0) {
        if (p1Pts > p2Pts) winner = 'p1';
        else if (p2Pts > p1Pts) winner = 'p2';
        else winner = 'tie';
      }
      days[d] = {
        date: d,
        p1: {
          totalPoints: p1Pts,
          basePoints: d1.basePoints,
          sharedBonus: d1.sharedBonus,
          streakBonus: d1.streakBonus,
          doubleDownDelta: d1.doubleDownDelta,
          level: pointsToHeatLevel(p1Pts),
          items: d1.items,
        },
        p2: {
          totalPoints: p2Pts,
          basePoints: d2.basePoints,
          sharedBonus: d2.sharedBonus,
          streakBonus: d2.streakBonus,
          doubleDownDelta: d2.doubleDownDelta,
          level: pointsToHeatLevel(p2Pts),
          items: d2.items,
        },
        winner,
        bothCrushed: p1Pts >= 5 && p2Pts >= 5,
      };
    }

    cursorWeek = addDays(cursorWeek, 7);
  }

  return days;
}
