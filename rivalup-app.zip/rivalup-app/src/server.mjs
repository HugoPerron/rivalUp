import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase, uid, seedDemoData, seedFreshData } from './db.mjs';
import {
  formatDateLocal,
  getWeekStart,
  getWeekDates,
  addDays,
  getDateEditability,
  scorePlayerWeek,
  resolveWeekMatch,
  buildHeatmapDays,
  calculatePlayerWeeklyBudget,
  pickQuestForWeek,
  DOUBLE_DOWN_WEEKLY_TOKENS,
  PROOF_CHALLENGE_WEEKLY_TOKENS,
  DIFFICULTY_POINTS,
} from './scoring.mjs';
import { sendWebPush } from './push.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT_DIR, 'public');
const UPLOADS_DIR = process.env.UPLOADS_DIR ? path.resolve(process.env.UPLOADS_DIR) : path.join(ROOT_DIR, 'uploads');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT_DIR, 'data');

fs.mkdirSync(UPLOADS_DIR, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = openDatabase(path.join(DATA_DIR, 'rivalup.db'));
const sseClients = new Set();

function broadcastUpdate(reason = 'state_changed') {
  const msg = `event: update\ndata: ${JSON.stringify({ reason, ts: Date.now() })}\n\n`;
  for (const res of sseClients) {
    try {
      res.write(msg);
    } catch {
      sseClients.delete(res);
    }
  }
}

async function notifyPlayerPush(targetPlayerId, title, body, url = '/') {
  try {
    const cfg = db.prepare('SELECT vapid_public_key, vapid_private_key_pem FROM match_config WHERE id = 1').get();
    const subs = db.prepare('SELECT * FROM push_subscriptions WHERE player_id = ?').all(targetPlayerId);
    if (!subs.length) return { sent: 0 };
    const vapidKeys = { publicKey: cfg.vapid_public_key, privateKeyPem: cfg.vapid_private_key_pem };
    let sent = 0;
    for (const sub of subs) {
      try {
        const res = await sendWebPush(sub, { title, body, url }, vapidKeys);
        if (res.ok) sent += 1;
        else if (res.status === 404 || res.status === 410) {
          db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(sub.id);
        }
      } catch {
        // Push endpoint unreachable (e.g. offline/local test) — non-fatal
      }
    }
    return { sent };
  } catch {
    return { sent: 0 };
  }
}

function getOtherPlayer(playerId) {
  return playerId === 'p1' ? 'p2' : 'p1';
}

function ensureWeekRow(weekStart, cfg) {
  let row = db.prepare('SELECT * FROM weeks WHERE week_start = ?').get(weekStart);
  if (!row) {
    const quest = pickQuestForWeek(weekStart);
    const diffWks = Math.max(0, Math.floor((new Date(weekStart) - new Date(cfg.season_start_week)) / (7 * 86400000)));
    const seasonNum = cfg.season_num + Math.floor(diffWks / 4);
    const weekInSeason = (diffWks % 4) + 1;
    db.prepare(`
      INSERT INTO weeks (week_start, season_num, week_in_season, wager_text, wager_paid, quest_id)
      VALUES (?, ?, ?, 'Loser buys flat whites ☕', 0, ?)
    `).run(weekStart, seasonNum, weekInSeason, quest.id);
    row = db.prepare('SELECT * FROM weeks WHERE week_start = ?').get(weekStart);
  }
  return row;
}

function buildFullState(now = new Date(), heatmapMonth = null) {
  const todayStr = formatDateLocal(now);
  const yesterdayStr = addDays(todayStr, -1);
  const currentWeek = getWeekStart(todayStr);

  const cfg = db.prepare('SELECT * FROM match_config WHERE id = 1').get();
  ensureWeekRow(currentWeek, cfg);

  const players = db.prepare('SELECT * FROM players ORDER BY id ASC').all();
  const habits = db.prepare(`SELECT * FROM habits WHERE active = 1 ORDER BY owner_id = 'shared' DESC, created_at ASC`).all();
  const checkins = db.prepare('SELECT * FROM checkins').all();
  const doubleDowns = db.prepare('SELECT * FROM double_downs').all();
  const weeks = db.prepare('SELECT * FROM weeks ORDER BY week_start DESC').all();
  const milestones = db.prepare('SELECT * FROM milestones ORDER BY weeks_required ASC').all();
  const feedRows = db.prepare('SELECT * FROM feed_events ORDER BY created_at DESC LIMIT 80').all();
  const pushCounts = db
    .prepare('SELECT player_id, COUNT(*) as cnt FROM push_subscriptions GROUP BY player_id')
    .all();

  const weeksMap = new Map(weeks.map((w) => [w.week_start, w]));
  const currentWeekMeta = weeksMap.get(currentWeek);

  // Score current week
  const p1Current = scorePlayerWeek({
    playerId: 'p1',
    weekStart: currentWeek,
    habits,
    checkins,
    doubleDowns,
    questId: currentWeekMeta.quest_id,
    weeklyBaseBudget: cfg.weekly_base_budget,
    now,
  });
  const p2Current = scorePlayerWeek({
    playerId: 'p2',
    weekStart: currentWeek,
    habits,
    checkins,
    doubleDowns,
    questId: currentWeekMeta.quest_id,
    weeklyBaseBudget: cfg.weekly_base_budget,
    now,
  });
  const currentMatch = resolveWeekMatch(p1Current, p2Current);

  // Score all historical weeks + calculate Season Record + Duo Flame Streak!
  const weeklyHistory = [];
  const chronWeeks = [...weeks].sort((a, b) => a.week_start.localeCompare(b.week_start));
  let duoStreak = 0;
  let longestDuoStreak = 0;
  let allTimeWins = { p1: 0, p2: 0, draw: 0 };
  let seasonWins = { p1: 0, p2: 0, draw: 0 };

  for (const w of chronWeeks) {
    const s1 = scorePlayerWeek({
      playerId: 'p1',
      weekStart: w.week_start,
      habits,
      checkins,
      doubleDowns,
      questId: w.quest_id,
      weeklyBaseBudget: cfg.weekly_base_budget,
      now,
    });
    const s2 = scorePlayerWeek({
      playerId: 'p2',
      weekStart: w.week_start,
      habits,
      checkins,
      doubleDowns,
      questId: w.quest_id,
      weeklyBaseBudget: cfg.weekly_base_budget,
      now,
    });
    const res = resolveWeekMatch(s1, s2);
    const isCompleted = w.week_start < currentWeek;

    if (isCompleted) {
      allTimeWins[res.winnerId] = (allTimeWins[res.winnerId] || 0) + 1;
      if (w.season_num === cfg.season_num) {
        seasonWins[res.winnerId] = (seasonWins[res.winnerId] || 0) + 1;
      }
      if (res.duoFlameEarned) {
        duoStreak += 1;
        if (duoStreak > longestDuoStreak) longestDuoStreak = duoStreak;
      } else {
        duoStreak = 0;
      }
    } else if (res.duoFlameEarned) {
      // Current week already locked in Duo Flame!
      duoStreak += 1;
      if (duoStreak > longestDuoStreak) longestDuoStreak = duoStreak;
    }

    weeklyHistory.push({
      weekStart: w.week_start,
      weekEnd: addDays(w.week_start, 6),
      seasonNum: w.season_num,
      weekInSeason: w.week_in_season,
      wagerText: w.wager_text,
      wagerPaid: Boolean(w.wager_paid),
      questId: w.quest_id,
      isCurrent: w.week_start === currentWeek,
      isCompleted,
      p1: {
        totalPoints: s1.totalPoints,
        basePoints: s1.basePoints,
        sharedBonus: s1.sharedBonus,
        streakBonus: s1.streakBonus,
        doubleDownDelta: s1.doubleDownDelta,
        questBonus: s1.questBonus,
        baseCompletionPct: s1.baseCompletionPct,
        hitDuoThreshold: s1.hitDuoThreshold,
      },
      p2: {
        totalPoints: s2.totalPoints,
        basePoints: s2.basePoints,
        sharedBonus: s2.sharedBonus,
        streakBonus: s2.streakBonus,
        doubleDownDelta: s2.doubleDownDelta,
        questBonus: s2.questBonus,
        baseCompletionPct: s2.baseCompletionPct,
        hitDuoThreshold: s2.hitDuoThreshold,
      },
      ...res,
    });
  }

  // Count proof challenges used this week per player
  const proofCounts = { p1: 0, p2: 0 };
  const weekStartTs = `${currentWeek}T00:00:00.000Z`;
  for (const ev of feedRows) {
    if (ev.type === 'proof_request' && ev.created_at >= weekStartTs) {
      proofCounts[ev.actor_id] = (proofCounts[ev.actor_id] || 0) + 1;
    }
  }

  // Heatmap window: cover 12 rolling weeks + requested month
  let heatStart = addDays(currentWeek, -77);
  let heatEnd = addDays(currentWeek, 6);
  if (heatmapMonth && /^\d{4}-\d{2}$/.test(heatmapMonth)) {
    const [y, m] = heatmapMonth.split('-').map(Number);
    const mStart = `${y}-${String(m).padStart(2, '0')}-01`;
    const lastDay = new Date(y, m, 0).getDate();
    const mEnd = `${y}-${String(m).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    if (mStart < heatStart) heatStart = mStart;
    if (mEnd > heatEnd) heatEnd = mEnd;
  }

  const heatmap = buildHeatmapDays({
    startDate: heatStart,
    endDate: heatEnd,
    habits,
    checkins,
    doubleDowns,
    weeksMap,
    weeklyBaseBudget: cfg.weekly_base_budget,
    now,
  });

  // Format feed events with parsed payload
  const feed = feedRows.map((ev) => ({
    ...ev,
    payload: JSON.parse(ev.payload_json || '{}'),
  }));

  // Today + yesterday checkins quick lookup
  const recentCheckins = checkins.filter((c) => c.date_str >= currentWeek && c.date_str <= addDays(currentWeek, 6));

  return {
    serverNow: now.toISOString(),
    todayStr,
    yesterdayStr,
    currentWeek,
    weekDates: getWeekDates(currentWeek),
    editability: {
      today: getDateEditability(todayStr, now),
      yesterday: getDateEditability(yesterdayStr, now),
    },
    config: {
      inviteCode: cfg.invite_code,
      seasonNum: cfg.season_num,
      seasonStartWeek: cfg.season_start_week,
      weeklyBaseBudget: cfg.weekly_base_budget,
      transferWindowOpen: Boolean(cfg.transfer_window_open),
      vapidPublicKey: cfg.vapid_public_key,
    },
    players,
    budgets: {
      p1: calculatePlayerWeeklyBudget(habits, 'p1'),
      p2: calculatePlayerWeeklyBudget(habits, 'p2'),
      p1IncludingPending: calculatePlayerWeeklyBudget(habits, 'p1', { includePending: true }),
      p2IncludingPending: calculatePlayerWeeklyBudget(habits, 'p2', { includePending: true }),
    },
    habits,
    currentWeekCheckins: recentCheckins,
    currentWeekDoubleDowns: doubleDowns.filter((d) => d.week_start === currentWeek),
    currentWeekMeta: {
      ...currentWeekMeta,
      wagerPaid: Boolean(currentWeekMeta.wager_paid),
    },
    scores: {
      p1: p1Current,
      p2: p2Current,
      match: currentMatch,
    },
    proofTokens: {
      p1: Math.max(0, PROOF_CHALLENGE_WEEKLY_TOKENS - proofCounts.p1),
      p2: Math.max(0, PROOF_CHALLENGE_WEEKLY_TOKENS - proofCounts.p2),
      maxPerWeek: PROOF_CHALLENGE_WEEKLY_TOKENS,
    },
    duoFlame: {
      currentStreak: duoStreak,
      longestStreak: longestDuoStreak,
      milestones: milestones.map((m) => ({
        ...m,
        unlocked: longestDuoStreak >= m.weeks_required,
      })),
    },
    records: {
      seasonWins,
      allTimeWins,
    },
    weeklyHistory: weeklyHistory.reverse(),
    heatmap,
    feed,
    pushEnabledByPlayer: Object.fromEntries(pushCounts.map((r) => [r.player_id, r.cnt > 0])),
  };
}

// ---------- HTTP Helpers ----------

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readJsonBody(req, maxBytes = 6 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > maxBytes) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function saveBase64Photo(dataUrl) {
  if (!dataUrl || typeof dataUrl !== 'string') return '';
  const match = dataUrl.match(/^data:image\/(png|jpeg|jpg|webp|gif);base64,(.+)$/i);
  if (!match) return '';
  const ext = match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
  const buf = Buffer.from(match[2], 'base64');
  if (buf.length > 4 * 1024 * 1024) throw new Error('Image exceeds 4MB limit');
  const filename = `${uid('proof')}.${ext}`;
  fs.writeFileSync(path.join(UPLOADS_DIR, filename), buf);
  return `/uploads/${filename}`;
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
};

function serveStaticFile(res, filePath) {
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404);
    res.end('Not found');
    return;
  }
  const ext = path.extname(filePath).toLowerCase();
  const headers = { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' };
  if (ext === '.js' || ext === '.css' || ext === '.html') {
    headers['Cache-Control'] = 'no-cache';
  }
  res.writeHead(200, headers);
  fs.createReadStream(filePath).pipe(res);
}

// ---------- Request Router ----------

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    // Health check for Render / Railway / Fly.io / Cloud Run
    if (req.method === 'GET' && pathname === '/healthz') {
      return sendJson(res, 200, { ok: true, app: 'rivalup' });
    }

    // Live SSE Stream for real-time 2-phone sync
    if (req.method === 'GET' && pathname === '/api/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      });
      res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);
      sseClients.add(res);
      req.on('close', () => sseClients.delete(res));
      return;
    }

    // Full App State
    if (req.method === 'GET' && pathname === '/api/state') {
      const month = url.searchParams.get('month');
      return sendJson(res, 200, buildFullState(new Date(), month));
    }

    // Check-in (Create / Update / Uncheck)
    if (req.method === 'POST' && pathname === '/api/checkin') {
      const body = await readJsonBody(req);
      const { habitId, playerId, dateStr, status = 'completed', numericValue = null, note = '', photoDataUrl = '' } = body;

      const editInfo = getDateEditability(dateStr, new Date());
      if (!editInfo.editable) {
        return sendJson(res, 400, { error: `This day is locked (${editInfo.label}).` });
      }

      const habit = db.prepare('SELECT * FROM habits WHERE id = ? AND active = 1').get(habitId);
      if (!habit) return sendJson(res, 404, { error: 'Habit not found' });

      if (status === 'uncheck') {
        db.prepare('DELETE FROM checkins WHERE habit_id = ? AND player_id = ? AND date_str = ?').run(
          habitId,
          playerId,
          dateStr
        );
        broadcastUpdate('checkin_removed');
        return sendJson(res, 200, { ok: true, state: buildFullState() });
      }

      let finalStatus = status;
      let finalVal = numericValue;
      if (habit.kind === 'numeric') {
        finalVal = Number(numericValue ?? habit.target_value);
        finalStatus = finalVal >= habit.target_value ? 'completed' : 'progress';
      }

      const existing = db
        .prepare('SELECT * FROM checkins WHERE habit_id = ? AND player_id = ? AND date_str = ?')
        .get(habitId, playerId, dateStr);
      const photoUrl = photoDataUrl ? saveBase64Photo(photoDataUrl) : existing?.photo_url || '';
      const nowIso = new Date().toISOString();

      let checkinId;
      if (existing) {
        checkinId = existing.id;
        db.prepare(
          'UPDATE checkins SET status = ?, numeric_value = ?, note = ?, photo_url = ?, logged_at = ? WHERE id = ?'
        ).run(finalStatus, finalVal, note ?? existing.note, photoUrl, nowIso, checkinId);
      } else {
        checkinId = uid('chk');
        db.prepare(`
          INSERT INTO checkins (id, habit_id, player_id, date_str, status, numeric_value, note, photo_url, logged_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(checkinId, habitId, playerId, dateStr, finalStatus, finalVal, note || '', photoUrl, nowIso);
      }

      if (finalStatus === 'completed' || finalStatus === 'slipped') {
        const actor = db.prepare('SELECT name FROM players WHERE id = ?').get(playerId);
        const ptsLabel = finalStatus === 'completed' ? DIFFICULTY_POINTS[habit.difficulty] : 0;
        db.prepare(`
          INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
          VALUES (?, 'checkin', ?, NULL, ?, ?, ?)
        `).run(
          uid('ev'),
          playerId,
          checkinId,
          JSON.stringify({
            habitTitle: habit.title,
            kind: habit.kind,
            status: finalStatus,
            isShared: habit.owner_id === 'shared',
            numericValue: finalVal,
            unit: habit.unit,
            note: note || '',
            photoUrl,
            points: ptsLabel,
            dateStr,
          }),
          nowIso
        );

        if (habit.owner_id === 'shared' && finalStatus === 'completed') {
          notifyPlayerPush(
            getOtherPlayer(playerId),
            `⚔️ ${actor.name} crushed a Shared Habit!`,
            `${habit.title}${note ? ` — "${note}"` : ''}`
          );
        }
      }

      broadcastUpdate('checkin');
      return sendJson(res, 200, { ok: true, checkinId, state: buildFullState() });
    }

    // Activate or Cancel Double Down (before completing!)
    if (req.method === 'POST' && pathname === '/api/double-down') {
      const { habitId, playerId, dateStr, action = 'activate' } = await readJsonBody(req);
      const editInfo = getDateEditability(dateStr, new Date());
      if (!editInfo.editable) return sendJson(res, 400, { error: 'Cannot change Double Down on a locked day.' });

      const weekStart = getWeekStart(dateStr);
      const existingCheckin = db
        .prepare(`SELECT id FROM checkins WHERE habit_id = ? AND player_id = ? AND date_str = ? AND status = 'completed'`)
        .get(habitId, playerId, dateStr);
      if (existingCheckin) {
        return sendJson(res, 400, { error: 'Double Down must be called BEFORE completing the habit!' });
      }

      if (action === 'cancel') {
        db.prepare('DELETE FROM double_downs WHERE habit_id = ? AND player_id = ? AND date_str = ?').run(
          habitId,
          playerId,
          dateStr
        );
        broadcastUpdate('double_down');
        return sendJson(res, 200, { ok: true, state: buildFullState() });
      }

      const used = db
        .prepare('SELECT COUNT(*) as cnt FROM double_downs WHERE player_id = ? AND week_start = ?')
        .get(playerId, weekStart).cnt;
      if (used >= DOUBLE_DOWN_WEEKLY_TOKENS) {
        return sendJson(res, 400, { error: `You already used all ${DOUBLE_DOWN_WEEKLY_TOKENS} Double Downs this week.` });
      }

      const habit = db.prepare('SELECT * FROM habits WHERE id = ?').get(habitId);
      const actor = db.prepare('SELECT name FROM players WHERE id = ?').get(playerId);
      const nowIso = new Date().toISOString();

      db.prepare(`
        INSERT OR IGNORE INTO double_downs (id, habit_id, player_id, week_start, date_str, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(uid('dd'), habitId, playerId, weekStart, dateStr, nowIso);

      db.prepare(`
        INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
        VALUES (?, 'double_down', ?, ?, NULL, ?, ?)
      `).run(
        uid('ev'),
        playerId,
        getOtherPlayer(playerId),
        JSON.stringify({ habitTitle: habit?.title || 'Habit', difficulty: habit?.difficulty || 1, dateStr }),
        nowIso
      );

      notifyPlayerPush(
        getOtherPlayer(playerId),
        `🎲 ${actor.name} called DOUBLE DOWN!`,
        `Betting 2x points on "${habit?.title}" today!`
      );

      broadcastUpdate('double_down');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Create Habit (auto-approved during Transfer Window; pending friend approval mid-season)
    if (req.method === 'POST' && pathname === '/api/habits') {
      const body = await readJsonBody(req);
      const {
        ownerId,
        proposedBy,
        title,
        kind = 'check',
        cadence = 'daily',
        targetCount = 7,
        targetValue = 1,
        unit = '',
        difficulty = 1,
      } = body;

      if (!title?.trim()) return sendJson(res, 400, { error: 'Habit title is required.' });
      const cfg = db.prepare('SELECT * FROM match_config WHERE id = 1').get();
      const approvalStatus = cfg.transfer_window_open ? 'approved' : 'pending';
      const nowIso = new Date().toISOString();
      const id = uid('hab');

      db.prepare(`
        INSERT INTO habits (id, owner_id, title, kind, cadence, target_count, target_value, unit, difficulty, active, approval_status, proposed_by, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
      `).run(
        id,
        ownerId,
        title.trim(),
        kind,
        cadence,
        cadence === 'daily' ? 7 : Math.min(7, Math.max(1, Number(targetCount || 3))),
        Math.max(1, Number(targetValue || 1)),
        unit.trim(),
        Math.min(3, Math.max(1, Number(difficulty || 1))),
        approvalStatus,
        proposedBy,
        nowIso
      );

      // If in transfer window, reset friend's season approval so they sign off on the new lineup
      if (cfg.transfer_window_open) {
        db.prepare('UPDATE players SET approved_season = 0 WHERE id = ?').run(getOtherPlayer(proposedBy));
      } else {
        const actor = db.prepare('SELECT name FROM players WHERE id = ?').get(proposedBy);
        db.prepare(`
          INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
          VALUES (?, 'approval', ?, ?, NULL, ?, ?)
        `).run(
          uid('ev'),
          proposedBy,
          getOtherPlayer(proposedBy),
          JSON.stringify({ habitId: id, habitTitle: title.trim(), difficulty, status: 'pending' }),
          nowIso
        );
        notifyPlayerPush(
          getOtherPlayer(proposedBy),
          `⚖️ Fair-Play Check from ${actor.name}`,
          `Proposed mid-season habit: "${title.trim()}" (${difficulty} pt)`
        );
      }

      broadcastUpdate('habit_added');
      return sendJson(res, 200, { ok: true, id, state: buildFullState() });
    }

    // Approve / Decline Mid-Season Habit or Archive Habit
    if (req.method === 'POST' && pathname.startsWith('/api/habits/')) {
      const parts = pathname.split('/');
      const habitId = parts[3];
      const action = parts[4];
      const body = await readJsonBody(req);

      if (action === 'approve') {
        db.prepare(`UPDATE habits SET approval_status = 'approved' WHERE id = ?`).run(habitId);
        broadcastUpdate('habit_approved');
        return sendJson(res, 200, { ok: true, state: buildFullState() });
      }
      if (action === 'delete' || action === 'decline') {
        db.prepare('UPDATE habits SET active = 0 WHERE id = ?').run(habitId);
        broadcastUpdate('habit_removed');
        return sendJson(res, 200, { ok: true, state: buildFullState() });
      }
      if (action === 'update') {
        const { title, difficulty, targetCount, targetValue, unit } = body;
        db.prepare(
          'UPDATE habits SET title = COALESCE(?, title), difficulty = COALESCE(?, difficulty), target_count = COALESCE(?, target_count), target_value = COALESCE(?, target_value), unit = COALESCE(?, unit) WHERE id = ?'
        ).run(title ?? null, difficulty ?? null, targetCount ?? null, targetValue ?? null, unit ?? null, habitId);
        broadcastUpdate('habit_updated');
        return sendJson(res, 200, { ok: true, state: buildFullState() });
      }
    }

    // Season Transfer Window & Fair-Play Approval
    if (req.method === 'POST' && pathname === '/api/season/approve') {
      const { playerId } = await readJsonBody(req);
      const cfg = db.prepare('SELECT * FROM match_config WHERE id = 1').get();
      db.prepare('UPDATE players SET approved_season = ? WHERE id = ?').run(cfg.season_num, playerId);

      // If BOTH players approved, automatically lock the Transfer Window!
      const players = db.prepare('SELECT approved_season FROM players').all();
      if (players.every((p) => p.approved_season >= cfg.season_num)) {
        db.prepare('UPDATE match_config SET transfer_window_open = 0 WHERE id = 1').run();
      }
      broadcastUpdate('season_approved');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    if (req.method === 'POST' && pathname === '/api/season/settings') {
      const { weeklyBaseBudget, transferWindowOpen, startNewSeason } = await readJsonBody(req);
      const cfg = db.prepare('SELECT * FROM match_config WHERE id = 1').get();
      if (weeklyBaseBudget !== undefined) {
        const clamped = Math.min(60, Math.max(20, Number(weeklyBaseBudget)));
        db.prepare('UPDATE match_config SET weekly_base_budget = ? WHERE id = 1').run(clamped);
      }
      if (transferWindowOpen !== undefined) {
        db.prepare('UPDATE match_config SET transfer_window_open = ? WHERE id = 1').run(transferWindowOpen ? 1 : 0);
        if (transferWindowOpen) {
          db.prepare('UPDATE players SET approved_season = 0').run();
        }
      }
      if (startNewSeason) {
        const nextSeason = cfg.season_num + 1;
        const currWeek = getWeekStart(formatDateLocal(new Date()));
        db.prepare(
          'UPDATE match_config SET season_num = ?, season_start_week = ?, transfer_window_open = 1 WHERE id = 1'
        ).run(nextSeason, currWeek);
        db.prepare('UPDATE players SET approved_season = 0').run();
      }
      broadcastUpdate('season_settings');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Wager update / Paid toggle
    if (req.method === 'POST' && pathname === '/api/wager') {
      const { weekStart, wagerText, wagerPaid } = await readJsonBody(req);
      const cfg = db.prepare('SELECT * FROM match_config WHERE id = 1').get();
      const targetWeek = weekStart || getWeekStart(formatDateLocal(new Date()));
      ensureWeekRow(targetWeek, cfg);

      if (wagerText !== undefined) {
        db.prepare('UPDATE weeks SET wager_text = ? WHERE week_start = ?').run(wagerText.trim(), targetWeek);
      }
      if (wagerPaid !== undefined) {
        db.prepare('UPDATE weeks SET wager_paid = ? WHERE week_start = ?').run(wagerPaid ? 1 : 0, targetWeek);
      }
      broadcastUpdate('wager');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Add / Delete Duo Flame Milestones
    if (req.method === 'POST' && pathname === '/api/milestones') {
      const { weeksRequired, title, emoji = '🎉', deleteId } = await readJsonBody(req);
      if (deleteId) {
        db.prepare('DELETE FROM milestones WHERE id = ?').run(deleteId);
      } else if (title?.trim()) {
        db.prepare('INSERT INTO milestones (id, weeks_required, title, emoji) VALUES (?, ?, ?, ?)').run(
          uid('ms'),
          Math.max(1, Number(weeksRequired || 4)),
          title.trim(),
          emoji
        );
      }
      broadcastUpdate('milestones');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Banter: Cheer / Fire / Cheeky Taunt
    if (req.method === 'POST' && pathname === '/api/feed/taunt') {
      const { actorId, emoji = '👀', text, checkinId = null } = await readJsonBody(req);
      if (!text?.trim()) return sendJson(res, 400, { error: 'Message required' });
      const targetId = getOtherPlayer(actorId);
      const actor = db.prepare('SELECT name FROM players WHERE id = ?').get(actorId);
      const nowIso = new Date().toISOString();

      db.prepare(`
        INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
        VALUES (?, 'taunt', ?, ?, ?, ?, ?)
      `).run(uid('ev'), actorId, targetId, checkinId, JSON.stringify({ emoji, text: text.trim() }), nowIso);

      notifyPlayerPush(targetId, `${emoji} ${actor.name} nudged you`, text.trim());
      broadcastUpdate('taunt');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // "Pics or it didn't happen!" Proof Challenge
    if (req.method === 'POST' && pathname === '/api/proof/request') {
      const { actorId, checkinId, message = "Pics or it didn't happen! 📸" } = await readJsonBody(req);
      const currentWeek = getWeekStart(formatDateLocal(new Date()));
      const weekStartTs = `${currentWeek}T00:00:00.000Z`;
      const used = db
        .prepare(`SELECT COUNT(*) as cnt FROM feed_events WHERE type = 'proof_request' AND actor_id = ? AND created_at >= ?`)
        .get(actorId, weekStartTs).cnt;

      if (used >= PROOF_CHALLENGE_WEEKLY_TOKENS) {
        return sendJson(res, 400, { error: `You used all ${PROOF_CHALLENGE_WEEKLY_TOKENS} proof challenges this week!` });
      }

      const chk = db.prepare('SELECT * FROM checkins WHERE id = ?').get(checkinId);
      if (!chk) return sendJson(res, 404, { error: 'Check-in not found' });
      const habit = db.prepare('SELECT title FROM habits WHERE id = ?').get(chk.habit_id);
      const actor = db.prepare('SELECT name FROM players WHERE id = ?').get(actorId);
      const targetId = chk.player_id;
      const nowIso = new Date().toISOString();

      db.prepare(`
        INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
        VALUES (?, 'proof_request', ?, ?, ?, ?, ?)
      `).run(
        uid('ev'),
        actorId,
        targetId,
        checkinId,
        JSON.stringify({ habitTitle: habit?.title || 'Habit', message, resolved: false }),
        nowIso
      );

      notifyPlayerPush(
        targetId,
        `📸 ${actor.name}: Pics or it didn't happen!`,
        `Prove your "${habit?.title}" check-in!`
      );
      broadcastUpdate('proof_request');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Reply to a Proof Challenge with photo / note
    if (req.method === 'POST' && pathname === '/api/proof/submit') {
      const { eventId, actorId, note = '', photoDataUrl = '' } = await readJsonBody(req);
      const ev = db.prepare('SELECT * FROM feed_events WHERE id = ?').get(eventId);
      if (!ev) return sendJson(res, 404, { error: 'Challenge not found' });

      const photoUrl = photoDataUrl ? saveBase64Photo(photoDataUrl) : '';
      const payload = JSON.parse(ev.payload_json || '{}');
      payload.resolved = true;
      payload.replyNote = note;
      payload.replyPhotoUrl = photoUrl;
      db.prepare('UPDATE feed_events SET payload_json = ? WHERE id = ?').run(JSON.stringify(payload), eventId);

      if (ev.checkin_id && (photoUrl || note)) {
        db.prepare(
          `UPDATE checkins SET photo_url = CASE WHEN ? != '' THEN ? ELSE photo_url END, note = CASE WHEN ? != '' THEN ? ELSE note END WHERE id = ?`
        ).run(photoUrl, photoUrl, note, note, ev.checkin_id);
      }

      const actor = db.prepare('SELECT name FROM players WHERE id = ?').get(actorId);
      const nowIso = new Date().toISOString();
      db.prepare(`
        INSERT INTO feed_events (id, type, actor_id, target_id, checkin_id, payload_json, created_at)
        VALUES (?, 'proof_reply', ?, ?, ?, ?, ?)
      `).run(
        uid('ev'),
        actorId,
        ev.actor_id,
        ev.checkin_id,
        JSON.stringify({ habitTitle: payload.habitTitle, note, photoUrl }),
        nowIso
      );

      notifyPlayerPush(
        ev.actor_id,
        `✅ ${actor.name} brought receipts!`,
        `Proof submitted for "${payload.habitTitle}"`
      );
      broadcastUpdate('proof_reply');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Update Player Profile (name, emoji, signature color)
    if (req.method === 'POST' && pathname === '/api/player') {
      const { playerId, name, emoji, color } = await readJsonBody(req);
      db.prepare(
        'UPDATE players SET name = COALESCE(?, name), emoji = COALESCE(?, emoji), color = COALESCE(?, color) WHERE id = ?'
      ).run(name?.trim() || null, emoji || null, color || null, playerId);
      broadcastUpdate('player_updated');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Push Subscription + Test Push
    if (req.method === 'POST' && pathname === '/api/push/subscribe') {
      const { playerId, subscription } = await readJsonBody(req);
      if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
        return sendJson(res, 400, { error: 'Invalid push subscription' });
      }
      db.prepare(`
        INSERT INTO push_subscriptions (id, player_id, endpoint, p256dh, auth, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(endpoint) DO UPDATE SET player_id = excluded.player_id, p256dh = excluded.p256dh, auth = excluded.auth
      `).run(uid('sub'), playerId, subscription.endpoint, subscription.keys.p256dh, subscription.keys.auth, new Date().toISOString());
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    if (req.method === 'POST' && pathname === '/api/push/test') {
      const { playerId } = await readJsonBody(req);
      const resPush = await notifyPlayerPush(
        playerId,
        '🏆 RivalUp Push Active!',
        'You will get buzzed for taunts, Double Downs, and "Pics or it didn\'t happen"!'
      );
      return sendJson(res, 200, { ok: true, ...resPush });
    }

    // Reset controls (Fresh Day 1 or Restore Demo Season)
    if (req.method === 'POST' && pathname === '/api/reset-fresh') {
      seedFreshData(db, new Date());
      broadcastUpdate('reset_fresh');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }
    if (req.method === 'POST' && pathname === '/api/reset-demo') {
      seedDemoData(db, new Date());
      broadcastUpdate('reset_demo');
      return sendJson(res, 200, { ok: true, state: buildFullState() });
    }

    // Serve uploaded proof photos
    if (req.method === 'GET' && pathname.startsWith('/uploads/')) {
      const safeName = path.basename(pathname);
      return serveStaticFile(res, path.join(UPLOADS_DIR, safeName));
    }

    // Serve PWA static files
    const targetFile = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
    const resolved = path.resolve(PUBLIC_DIR, targetFile);
    if (!resolved.startsWith(PUBLIC_DIR)) {
      res.writeHead(403);
      return res.end('Forbidden');
    }
    if (fs.existsSync(resolved) && !fs.statSync(resolved).isDirectory()) {
      return serveStaticFile(res, resolved);
    }
    return serveStaticFile(res, path.join(PUBLIC_DIR, 'index.html'));
  } catch (err) {
    console.error('[RivalUp Error]', err);
    return sendJson(res, 500, { error: err.message || 'Internal server error' });
  }
});

const PORT = Number(process.env.PORT || 3456);
const HOST = process.env.HOST || '0.0.0.0';

server.listen(PORT, HOST, () => {
  console.log(`RivalUp running at http://${HOST}:${PORT}`);
});
