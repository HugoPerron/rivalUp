/**
 * Zero-dependency RFC 8291 (aes128gcm) + VAPID ES256 Web Push sender using Node 24 crypto.
 * Works with iOS Safari PWA (Add to Home Screen) and Android Chrome.
 */
import crypto from 'node:crypto';

function b64urlEncode(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function b64urlDecode(str) {
  const pad = '='.repeat((4 - (str.length % 4)) % 4);
  return Buffer.from(str.replace(/-/g, '+').replace(/_/g, '/') + pad, 'base64');
}

export function generateVapidKeys() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
  });
  const pubJwk = publicKey.export({ format: 'jwk' });
  const rawPub = Buffer.concat([Buffer.from([0x04]), b64urlDecode(pubJwk.x), b64urlDecode(pubJwk.y)]);
  const privPem = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
  return {
    publicKey: b64urlEncode(rawPub),
    privateKeyPem: privPem,
  };
}

function buildVapidAuthHeader(endpoint, vapidPublicKey, vapidPrivateKeyPem, subject = 'mailto:rivalup@example.com') {
  const url = new URL(endpoint);
  const audience = `${url.protocol}//${url.host}`;
  const header = b64urlEncode(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const exp = Math.floor(Date.now() / 1000) + 12 * 3600;
  const payload = b64urlEncode(JSON.stringify({ aud: audience, exp, sub: subject }));
  const unsigned = `${header}.${payload}`;

  const signature = crypto.sign('sha256', Buffer.from(unsigned), {
    key: vapidPrivateKeyPem,
    dsaEncoding: 'ieee-p1363',
  });
  const jwt = `${unsigned}.${b64urlEncode(signature)}`;
  return `vapid t=${jwt}, k=${vapidPublicKey}`;
}

/** RFC 8291 aes128gcm payload encryption */
function encryptWebPushPayload(payloadStr, subscriberP256dhB64, subscriberAuthB64) {
  const uaPublic = b64urlDecode(subscriberP256dhB64);
  const authSecret = b64urlDecode(subscriberAuthB64);

  const asEcdh = crypto.createECDH('prime256v1');
  const asPublic = asEcdh.generateKeys();
  const sharedSecret = asEcdh.computeSecret(uaPublic);

  const salt = crypto.randomBytes(16);

  // IKM = HKDF(salt=auth_secret, ikm=ecdh_secret, info="WebPush: info\0" || ua_public || as_public, len=32)
  const keyInfo = Buffer.concat([Buffer.from('WebPush: info\0', 'utf8'), uaPublic, asPublic]);
  const ikm = Buffer.from(crypto.hkdfSync('sha256', sharedSecret, authSecret, keyInfo, 32));

  // CEK = HKDF(salt=salt, ikm=IKM, info="Content-Encoding: aes128gcm\0", len=16)
  const cek = Buffer.from(
    crypto.hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0', 'utf8'), 16)
  );

  // NONCE = HKDF(salt=salt, ikm=IKM, info="Content-Encoding: nonce\0", len=12)
  const nonce = Buffer.from(
    crypto.hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0', 'utf8'), 12)
  );

  // Plaintext + 0x02 delimiter (final record)
  const plaintext = Buffer.concat([Buffer.from(payloadStr, 'utf8'), Buffer.from([0x02])]);
  const cipher = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final(), cipher.getAuthTag()]);

  // Record header: salt (16) || rs (4, uint32be=4096) || idlen (1, 65) || keyid (65, asPublic)
  const rs = Buffer.alloc(4);
  rs.writeUInt32BE(4096, 0);
  const header = Buffer.concat([salt, rs, Buffer.from([asPublic.length]), asPublic]);

  return Buffer.concat([header, ciphertext]);
}

export async function sendWebPush(subscription, payloadObj, vapidKeys) {
  const payloadStr = JSON.stringify(payloadObj);
  const body = encryptWebPushPayload(payloadStr, subscription.p256dh, subscription.auth);
  const authorization = buildVapidAuthHeader(
    subscription.endpoint,
    vapidKeys.publicKey,
    vapidKeys.privateKeyPem
  );

  const res = await fetch(subscription.endpoint, {
    method: 'POST',
    headers: {
      Authorization: authorization,
      TTL: '86400',
      'Content-Type': 'application/octet-stream',
      'Content-Encoding': 'aes128gcm',
      'Content-Length': String(body.length),
    },
    body,
  });

  return { ok: res.ok, status: res.status };
}
